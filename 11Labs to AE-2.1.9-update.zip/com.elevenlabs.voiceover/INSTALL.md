# ElevenLabs to AE — Installation Guide

## Prerequisites

| Requirement | Version | Notes |
|---|---|---|
| Adobe After Effects | 2022+ | |
| ElevenLabs API Key | — | from elevenlabs.io |

---

## macOS

### Step 1 — Enable CEP Debug Mode
Open **Terminal** and paste all 4 lines, then press Enter:
```bash
defaults write com.adobe.CSXS.9  PlayerDebugMode 1
defaults write com.adobe.CSXS.10 PlayerDebugMode 1
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
```

### Step 2 — Install ZXP Installer
Download and install **ZXP Installer** from [zxpinstaller.com](https://www.zxpinstaller.com/)

### Step 3 — Install the Plugin
Drag `11Labs to AE-{version}.zxp` into ZXP Installer and click **Install**.

### Step 4 — Restart After Effects
Open AE → **Window → Extensions → ElevenLabs**

### Step 5 — Enter Your API Key
Click the settings icon → paste your ElevenLabs API key → Save.

---

## Windows

### Step 1 — Enable CEP Debug Mode
Press `Win + R`, type `cmd`, press `Ctrl + Shift + Enter` (run as Administrator), then paste:
```
reg add "HKCU\Software\Adobe\CSXS.9"  /v PlayerDebugMode /t REG_SZ /d "1" /f
reg add "HKCU\Software\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d "1" /f
reg add "HKCU\Software\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d "1" /f
reg add "HKCU\Software\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d "1" /f
```

### Step 2 — Install ZXP Installer
Download and install **ZXP Installer** from [zxpinstaller.com](https://www.zxpinstaller.com/)

### Step 3 — Install the Plugin
Drag `11Labs to AE-{version}.zxp` into ZXP Installer and click **Install**.

### Step 4 — Restart After Effects
Open AE → **Window → Extensions → ElevenLabs**

### Step 5 — Enter Your API Key
Click the settings icon → paste your ElevenLabs API key → Save.

---

## Updating

1. In the panel, click the **gear icon → Install Update**
2. Drop the `11Labs to AE.zip` file → click **Install** → **Reload Extension**

No AE restart needed for updates.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Panel not visible in AE | Check CEP debug mode (Step 1) and restart AE |
| API key rejected | Verify key at elevenlabs.io → Profile → API Keys |
| Audio not placed in comp | Make sure a comp is open and active in AE |
