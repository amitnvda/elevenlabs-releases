#!/bin/bash
# ElevenLabs Voiceover — Mac Uninstaller

PLUGIN_NAME="com.elevenlabs.voiceover"
INSTALL_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions/$PLUGIN_NAME"

echo ""
echo "  ElevenLabs Voiceover — Uninstaller"
echo ""

if [ -d "$INSTALL_DIR" ] || [ -L "$INSTALL_DIR" ]; then
  rm -rf "$INSTALL_DIR"
  echo "  Removed: $INSTALL_DIR"
else
  echo "  Plugin not found at: $INSTALL_DIR"
fi

echo "  Done. Restart After Effects or Premiere Pro to complete removal."
echo ""
