# 11Labs ➡️ AE — Documentation

**Version:** 1.2 | **Platform:** Adobe After Effects (Mac & Windows)

---

11Labs ➡️ AE is an internal After Effects panel built for the NVIDIA video production team. It connects directly to ElevenLabs' text-to-speech API and lets you generate, save, and place AI voiceovers on your AE timeline — without switching apps or managing files manually.

Type your script, choose a voice and model, click Generate. The audio is saved to your project's VO folder and dropped on the timeline at the playhead. Settings like voice, model, speed, and stability are remembered between sessions.

---

## Table of Contents

1. [What is this?](#what-is-this)
2. [Requirements](#requirements)
3. [Installation](#installation)
4. [First-Time Setup](#first-time-setup)
5. [Panel Overview](#panel-overview)
6. [Generating a Voiceover](#generating-a-voiceover)
7. [Voice Settings](#voice-settings)
8. [Output Folder Options](#output-folder-options)
9. [Models](#models)
10. [Tips](#tips)
11. [Troubleshooting](#troubleshooting)
12. [Version History](#version-history)

---

## What is this?

11Labs ➡️ AE is an After Effects panel that lets you generate AI voiceovers from ElevenLabs and place them directly on your timeline — without leaving After Effects.

Type your script, pick a voice, click Generate. The audio file is saved and imported into your AE project automatically.

---

## Requirements

- Adobe After Effects 2022 or later (v22.0+)
- An [ElevenLabs](https://elevenlabs.io) account (free or paid)
- macOS or Windows 10/11

---

## Installation

### Mac

1. Unzip `ElevenLabsVoiceover.zip`
2. Open the `ae-elevenlabs-plugin` folder
3. Double-click `install.sh`
   - If macOS blocks it: right-click → **Open With → Terminal**
4. Restart After Effects
5. Go to **Window → Extensions → 11Labs ➡️ AE**

### Windows

1. Unzip `ElevenLabsVoiceover.zip`
2. Open the `ae-elevenlabs-plugin` folder
3. Right-click `install.bat` → **Run as Administrator**
4. Restart After Effects
5. Go to **Window → Extensions → 11Labs -> AE**

> The installer enables CEP debug mode, which is required for unsigned extensions to load in After Effects. This is a one-time, per-machine step.

---

## First-Time Setup

1. Go to [elevenlabs.io](https://elevenlabs.io) → Log in
2. Click your profile (top right) → **Profile + API Key**
3. Copy your key — it starts with `sk_...`
4. In the AE panel, paste it into the **API Key** field and click **Save**

Your voices will load automatically. The key is stored locally on your machine only and is never sent anywhere except ElevenLabs' own API.

---

## Panel Overview

```
┌─────────────────────────────────────────┐
│ ◉ 11Labs ➡️ AE                    v1.2 │  ← 1
├─────────────────────────────────────────┤
│ API KEY                                 │
│ ┌───────────────────────────┐ ┌───────┐ │
│ │ sk_••••••••••••••••••••• │ │ Save  │ │  ← 2
│ └───────────────────────────┘ └───────┘ │
├─────────────────────────────────────────┤
│ VOICE                  MODEL            │
│ ┌──────────────────┐ ┌───────────────┐  │
│ │ Rachel         ▾ │ │ Eleven v3   ▾ │  │  ← 3
│ └──────────────────┘ └───────────────┘  │
├─────────────────────────────────────────┤
│ TEXT TO SYNTHESIZE                      │
│ ┌─────────────────────────────────────┐ │
│ │                                     │ │  ← 4
│ │  Type your voiceover script here…   │ │
│ └─────────────────────────────────────┘ │
│                              0 / 5000   │  ← 5
├─────────────────────────────────────────┤
│ ┌─────────────────────────────────────┐ │
│ │    Generate & Place in Timeline     │ │  ← 6
│ └─────────────────────────────────────┘ │
├─────────────────────────────────────────┤
│ ● Ready                                 │  ← 7
├─────────────────────────────────────────┤
│ VOICE SETTINGS                       ▾  │  ← 8
│  Stability   ──────●──   0.50          │
│  Similarity  ────────●   0.75          │
│  Speed       ───●──────  0.90          │
│  ☑ Auto-save to project VO folder      │  ← 9
│  ☐ Save to specific folder             │
│  [ Open Saved Folder             ]     │  ← 10
├─────────────────────────────────────────┤
│ RECENT GENERATIONS                      │  ← 11
│  Rachel  Welcome to our Q3 review… 9:41 │
└─────────────────────────────────────────┘
```

| # | Element | Description |
|---|---|---|
| **1** | Header | Plugin name and version |
| **2** | API Key | Paste your ElevenLabs key and click **Save** — voices load automatically |
| **3** | Voice & Model | Choose from all voices in your ElevenLabs account |
| **4** | Script | Type or paste your voiceover text (up to 5,000 characters) |
| **5** | Character counter | Turns orange near the limit; hard stops at 5,000 |
| **6** | Generate | Calls the API, saves the audio, and places it as a new layer at the playhead |
| **7** | Status bar | Shows progress, success, or error messages in real time |
| **8** | Voice Settings | Collapsible — fine-tune Stability, Similarity, and Speed |
| **9** | Output folder | Auto-save uses the project VO folder; or browse to a specific location |
| **10** | Open Saved Folder | Opens the audio destination in Finder (Mac) or Explorer (Windows) |
| **11** | Recent Generations | Last 10 generations with voice name, text preview, and timestamp |

---

## Generating a Voiceover

1. Open a composition in After Effects and move the playhead to where you want the audio to start
2. Select a **Voice** from the dropdown
3. Select a **Model** (Eleven v3 recommended)
4. Type or paste your script in the text area
5. Click **Generate & Place in Timeline**

The audio is generated, saved to your output folder, imported into the AE project, and placed as a new layer at the playhead — all automatically.

> The layer is named `EL: <filename>` in the AE timeline and is fully undoable with **Cmd+Z** (Mac) / **Ctrl+Z** (Windows).

---

## Voice Settings

Open the **Voice Settings** section in the panel to adjust these parameters before generating.

| Setting | Range | Default | What it does |
|---|---|---|---|
| **Stability** | 0 – 1 | 0.50 | Lower = more expressive and varied. Higher = more consistent. Start at 0.50. |
| **Similarity** | 0 – 1 | 0.75 | How closely the output matches the original voice. Higher = more accurate but can sound over-processed. |
| **Speed** | 0.7 – 1.2 | 0.90 | Controls delivery pace. Below 1.0 = slower, above 1.0 = faster. 0.7 and 1.2 are the API's hard limits. |

Settings are saved automatically between sessions.

---

## Output Folder Options

| Option | Behavior |
|---|---|
| **Auto-save to project VO folder** | Saves the file to `<project root>/Footage/Audio/VO/`. Requires the AE project to be saved and the folder to exist. |
| **Save to specific folder** | Saves to a custom folder you choose via Browse. |

Click **Open Saved Folder** at any time to open the destination in Finder / Explorer.

> **Note for Auto-save:** The plugin looks upward from the `.aep` file for a parent folder containing a `Footage/` subfolder, then saves into `Footage/Audio/VO/`. If that folder doesn't exist, switch to "Save to specific folder."

---

## Models

| Model | Best for |
|---|---|
| **Eleven v3** | Highest quality, most natural. Recommended for final output. |
| **Multilingual v2** | Multiple languages, excellent quality. |
| **Turbo v2.5** | Faster generation, good quality. |
| **Flash v2.5** | Fastest, suitable for quick drafts. |
| **Monolingual v1** | English only, legacy model. |

---

## Tips

**Getting the best take**
ElevenLabs' model is non-deterministic — the same script produces slightly different results each time. With Stability at 0.50, there's meaningful variation between runs. Generate 3–5 versions and pick the best one.

**Consistent reads**
Raise Stability to 0.75–0.80 if you need more predictable output across multiple generations.

**Natural pacing**
The default Speed of 0.90 produces a slightly measured, broadcast-style pace. Raise toward 1.0 for a more conversational speed.

**Layer naming**
All generated layers are prefixed with `EL:` so they're easy to identify and sort in your AE timeline.

---

## Troubleshooting

**Panel not showing under Window → Extensions**
Run the installer again, then fully quit and reopen After Effects.

**Voices didn't load / blank dropdown**
Double-check your API key. It should start with `sk_` and have no extra spaces. Click Save again to retry.

**"No active composition" error**
Make sure a composition is open and selected in the timeline before clicking Generate.

**"Project not saved" error**
Save your AE project file (Cmd+S / Ctrl+S) before generating when using Auto-save mode.

**"VO folder not found" error**
Your project must have a `Footage/Audio/VO/` folder at the root level. Create it, or switch to **Save to specific folder** in Voice Settings.

**Can't find the audio file**
Check your AE Project panel — the file is imported there automatically. It's also saved to the output folder you configured in Voice Settings.

---

## Version History

| Version | Notes |
|---|---|
| **v1.2** | Auto-save to project VO folder, Open Saved Folder button, Speed slider |
| **v1.0** | Initial release: API key, voice/model selection, generate & place on timeline, Stability/Similarity controls |

---

*11Labs ➡️ AE is an internal tool developed for NVIDIA video production. For questions or to report issues, contact the video production team.*
