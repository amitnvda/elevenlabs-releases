# 11Labs ➡️ AE | v1.4 — Quick Start Guide

---

## Installation

**Mac**

1. Open Terminal and run once to allow unsigned extensions:
   ```
   defaults write com.adobe.CSXS.9  PlayerDebugMode 1
   defaults write com.adobe.CSXS.10 PlayerDebugMode 1
   defaults write com.adobe.CSXS.11 PlayerDebugMode 1
   defaults write com.adobe.CSXS.12 PlayerDebugMode 1
   ```
   No output = success.
2. Download and install **[ZXP Installer](https://www.zxpinstaller.com/)**
3. Drag `11Labs to AE-1.4.0.zxp` onto ZXP Installer
4. Restart After Effects
5. Go to **Window → Extensions → 11Labs ➡️ AE**

**Windows**

1. Open Command Prompt as Administrator and run once to allow unsigned extensions:
   ```
   reg add "HKCU\SOFTWARE\Adobe\CSXS.9"  /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add "HKCU\SOFTWARE\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add "HKCU\SOFTWARE\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f
   reg add "HKCU\SOFTWARE\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f
   ```
2. Download and install **[ZXP Installer](https://www.zxpinstaller.com/)**
3. Drag `11Labs to AE-1.4.0.zxp` onto ZXP Installer
4. Restart After Effects
5. Go to **Window → Extensions → 11Labs → AE**

---

## Panel Overview

```
┌─────────────────────────────────────────┐
│ ◉ 11Labs ➡️ AE              v1.4  ↑    │ ← 1
├─────────────────────────────────────────┤
│ API KEY                                 │
│ ┌───────────────────────────┐ ┌───────┐ │
│ │ sk_••••••••••••••••••••• │ │ Save  │ │ ← 2
│ └───────────────────────────┘ └───────┘ │
├─────────────────────────────────────────┤
│ VOICE                  MODEL            │
│ ┌──────────────────┐ ┌───────────────┐  │
│ │ Rachel         ▾ │ │ Eleven v3   ▾ │  │ ← 3
│ └──────────────────┘ └───────────────┘  │
├─────────────────────────────────────────┤
│ TEXT TO SYNTHESIZE         [Import PPTX]│
│ ┌─────────────────────────────────────┐ │
│ │                                     │ │ ← 4
│ │  Type your voiceover script here…   │ │
│ └─────────────────────────────────────┘ │
│                              0 / 5000   │ ← 5
├─────────────────────────────────────────┤
│ OUTPUT FILENAME                         │
│ ┌─────────────────────────────────────┐ │
│ │ auto (EL_voice_timestamp.mp3)       │ │ ← 6
│ └─────────────────────────────────────┘ │
├─────────────────────────────────────────┤
│ ┌─────────────────────────────────────┐ │
│ │    Generate & Place in Timeline     │ │ ← 7
│ └─────────────────────────────────────┘ │
├─────────────────────────────────────────┤
│ ● Ready                                 │ ← 8
├─────────────────────────────────────────┤
│ VOICE SETTINGS                       ▾  │ ← 9
│  Speed       ───●──────  0.90          │
│  Pitch       ────────●   0%            │
│  Stability   ──────●──   0.50          │
│  Similarity  ────────●   0.75          │
│  ☑ Auto-save to project VO folder      │ ← 10
│  ☐ Save to specific folder             │
│  [ Open Saved Folder             ]     │ ← 11
│  ─────────────────────────────────     │
│  PLUGIN UPDATES                        │ ← 12
│  [ /Team Drive/Plugins    ] [Browse…]  │
│  [Check for Updates] [↑ Install v1.5]  │
├─────────────────────────────────────────┤
│ RECENT GENERATIONS                      │ ← 13
│  Rachel  Welcome to our Q3 review… 9:41 │
└─────────────────────────────────────────┘
```

| # | Element | Description |
|---|---|---|
| **1** | Header | Plugin name, version, and update badge (↑ appears when an update is available) |
| **2** | API Key | Paste your ElevenLabs key (`sk_...`) and click **Save** — voices load automatically |
| **3** | Voice & Model | Choose from your account's voices; **Eleven v3** recommended for best quality |
| **4** | Script + Import | Type or paste your script, or click **Import PPTX…** to pull notes from a presentation |
| **5** | Character counter | Turns orange near the 5,000-character limit |
| **6** | Output Filename | Leave blank for an auto-generated name, or type a custom one |
| **7** | Generate | Calls the ElevenLabs API, saves the audio, and places it as a new layer at the AE playhead |
| **8** | Status bar | Shows progress, success, or error messages |
| **9** | Voice Settings | Collapsible — fine-tune Speed, Pitch, Stability, and Similarity |
| **10** | Output folder | **Auto-save** places the file in the project's `Footage/Audio/VO/` folder; or browse to a custom location |
| **11** | Open Saved Folder | Opens the destination folder in Finder (Mac) or Explorer (Windows) |
| **12** | Plugin Updates | Set a shared drive folder path — panel checks for new versions automatically |
| **13** | Recent Generations | Last 10 generations — voice name, text preview, and timestamp |

---

## First-Time Setup

1. Go to [elevenlabs.io](https://elevenlabs.io) → Log in → Profile (top right) → **API Key**
2. Copy your key (starts with `sk_...`)
3. Paste it into the **API Key** field and click **Save**

Your voices load automatically. The key is stored locally and never shared.

---

## Generating a Voiceover

1. Open a composition and place the playhead where you want the audio to start
2. Pick a **Voice** and **Model**
3. Type your script (or import from PPTX — see below)
4. Click **Generate & Place in Timeline**

The audio is placed as a new layer at the playhead. Fully undoable with Cmd+Z / Ctrl+Z.

> The layer is named `EL: <filename>` in the AE timeline.

---

## Importing Scripts from PowerPoint (PPTX)

Use the **Import PPTX…** button to pull speaker notes directly from a presentation.

1. Click **Import PPTX…** next to the script field
2. A file picker opens — select your `.pptx` file
3. A slide picker appears showing each slide's number, title, and speaker notes
4. Click any slide to load its notes into the script field
5. Click **Import PPTX…** again to pick a different slide from the same file
6. Click **New file…** in the picker header to load a different presentation

> **Note:** Only speaker notes are imported — not the slide body text. Make sure your notes contain the full voiceover script for each slide.

---

## Voice Settings

| Setting | Range | Default | What it does |
|---|---|---|---|
| **Speed** | 0.7 – 1.2 | 0.90 | Below 1.0 = slower, above 1.0 = faster |
| **Pitch** | −15 – +15 | 0 | Shifts pitch in semitones (requires FFmpeg) |
| **Stability** | 0 – 1 | 0.50 | Lower = more expressive; higher = more consistent |
| **Similarity** | 0 – 1 | 0.75 | How closely output matches the original voice |

> **Pitch** requires [FFmpeg](https://ffmpeg.org) to be installed. On Mac, install via `brew install ffmpeg`. If FFmpeg is not found, the Pitch slider is disabled.

---

## Auto-Update

The panel can update itself from a shared drive folder — no manual reinstall needed.

**Setup (one-time, per user):**

1. Expand **Voice Settings** → scroll to **Plugin Updates**
2. Click **Browse…** → select the shared drive folder your admin maintains
3. Click **Check for Updates** — the panel will tell you if you're up to date

After that, the panel checks automatically every time it opens. When an update is found:
- A green **↑ v1.x** badge appears in the header
- Click the badge or **↑ Install vX.x** in Voice Settings
- Wait for "Updated — restart After Effects to apply"
- Restart AE

**For admins — publishing an update:**

1. Build the new version and create `11Labs to AE.zip`
2. Drop the ZIP into the shared folder (replace the old one)
3. Update `version.txt` in the same folder to the new version number (e.g. `1.5.0`)

Users will be notified on their next panel open.

---

## Troubleshooting

**Panel not showing** — Run the installer again, then fully quit and reopen After Effects.

**Voices didn't load** — Check your API key. It should start with `sk_` and have no extra spaces.

**"No active composition" error** — Open a composition before clicking Generate.

**VO folder not found** — Make sure your project has a `Footage/Audio/VO/` subfolder, or switch to "Save to specific folder" in Voice Settings.

**Can't find the audio file** — Check your AE Project panel — the file is imported there automatically.

**Pitch slider shows N/A** — FFmpeg is not installed or not found. Install it via Homebrew (`brew install ffmpeg`) on Mac, or download from [ffmpeg.org](https://ffmpeg.org) on Windows.

**PPTX import: slide has no notes** — Slides without speaker notes are shown dimmed in the picker. Add notes in PowerPoint's Notes pane and re-import.

**Update check: "folder not found"** — The shared drive may not be mounted. Connect to the drive and try again.

**Update check: "no version.txt"** — Ask your admin to add a `version.txt` file to the shared folder.

**"↑ Install" button does nothing** — Make sure After Effects is not in the middle of rendering. The update replaces files on disk — you must restart AE afterward.
