@echo off
:: ElevenLabs Voiceover -- Windows Installer
:: Supports After Effects and Premiere Pro.

setlocal enabledelayedexpansion

set PLUGIN_NAME=com.elevenlabs.voiceover
set SCRIPT_DIR=%~dp0
set INSTALL_DIR=%APPDATA%\Adobe\CEP\extensions\%PLUGIN_NAME%

echo.
echo   ElevenLabs to AE -- After Effects ^& Premiere Pro Plugin Installer
echo   --------------------------------------------------------------------
echo.

:: -- 1. Enable CEP debug mode --
echo   [1/3] Enabling CEP debug mode...
reg add "HKCU\SOFTWARE\Adobe\CSXS.9"  /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\SOFTWARE\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\SOFTWARE\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\SOFTWARE\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
echo         Done.

:: -- 2. Install plugin --
echo   [2/3] Installing plugin...
if not exist "%APPDATA%\Adobe\CEP\extensions" (
  mkdir "%APPDATA%\Adobe\CEP\extensions"
)

if exist "%INSTALL_DIR%" (
  rmdir /s /q "%INSTALL_DIR%"
)

:: Copy plugin files (excludes dev artifacts + secrets)
robocopy "%SCRIPT_DIR%." "%INSTALL_DIR%" /E /NFL /NDL /NJH /NJS /NC /NS /NP ^
  /XF .DS_Store *.env *.zxp build.sh install.sh install.bat uninstall.sh CLAUDE.md .gitignore ^
  /XD .git build >nul

if not exist "%INSTALL_DIR%" (
  echo         ERROR: copy failed.
  pause
  exit /b 1
)
echo         Installed to: %INSTALL_DIR%

:: -- 3. Verify --
echo   [3/3] Verifying...
if exist "%INSTALL_DIR%\CSXS\manifest.xml" (
  echo         OK -- manifest found.
) else (
  echo         ERROR: manifest.xml missing. Something went wrong.
  pause
  exit /b 1
)

echo.
echo   Installation complete!
echo.
echo   Next steps:
echo     1. Restart After Effects or Premiere Pro (fully quit and reopen)
echo     2. Go to  Window ^> Extensions ^> 11Labs -^> AE
echo     3. Enter your ElevenLabs API key and click Save
echo.
pause
