#!/bin/bash
# ElevenLabs Voiceover — Mac Installer
# Installs the plugin and enables CEP debug mode so unsigned extensions load.

set -e

PLUGIN_NAME="com.elevenlabs.voiceover"
PLUGIN_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions/$PLUGIN_NAME"

echo ""
echo "  ElevenLabs Voiceover — After Effects Plugin Installer"
echo "  ────────────────────────────────────────────────────────"
echo ""

# ── 1. Enable CEP debug mode (required for unsigned extensions) ──
echo "  [1/3] Enabling CEP debug mode..."
defaults write com.adobe.CSXS.9  PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.10 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.11 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.12 PlayerDebugMode 1 2>/dev/null || true
echo "       Done."

# ── 2. Create extensions directory if needed ──
echo "  [2/3] Installing plugin..."
mkdir -p "$HOME/Library/Application Support/Adobe/CEP/extensions"

# Remove old install if it exists
if [ -L "$INSTALL_DIR" ] || [ -d "$INSTALL_DIR" ]; then
  rm -rf "$INSTALL_DIR"
fi

# Copy plugin files
cp -r "$PLUGIN_DIR" "$INSTALL_DIR"
echo "       Installed to: $INSTALL_DIR"

# ── 3. Verify ──
echo "  [3/3] Verifying..."
if [ -f "$INSTALL_DIR/CSXS/manifest.xml" ]; then
  echo "       OK — manifest found."
else
  echo "       ERROR: manifest.xml missing. Something went wrong."
  exit 1
fi

echo ""
echo "  ✓ Installation complete!"
echo ""
echo "  Next steps:"
echo "    1. Restart After Effects (fully quit and reopen)"
echo "    2. Go to  Window > Extensions > 11Labs ➡️ AE"
echo "    3. Enter your ElevenLabs API key and click Save"
echo ""
