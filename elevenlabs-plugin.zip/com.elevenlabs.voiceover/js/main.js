/**
 * ElevenLabs Voiceover Panel - Main Logic
 * Handles API communication, file I/O, and ExtendScript bridge.
 */

/* global CSInterface */

(function () {
  'use strict';

  // ─── Node.js modules ───
  const _require = (typeof window.cep_node !== 'undefined')
    ? window.cep_node.require.bind(window.cep_node)
    : (typeof require !== 'undefined' ? require : null);

  if (!_require) {
    console.error('Node.js is not available in this CEP context. Check --enable-nodejs flag.');
  }

  const fs           = _require && _require('fs');
  const path         = _require && _require('path');
  const os           = _require && _require('os');
  const childProcess = _require && _require('child_process');
  const Buffer = (typeof window.cep_node !== 'undefined')
    ? window.cep_node.Buffer
    : (typeof Buffer !== 'undefined' ? Buffer : null);

  // ─── CEP bridge ───
  const cs = new CSInterface();
  const IS_PREMIERE = cs.getHostEnvironment().appName === 'PPRO';

  // ─── ElevenLabs API ───
  const API_BASE = 'https://api.elevenlabs.io/v1';

  // Available models — noSpeed: true means the speed param is not supported
  const MODELS = [
    { id: 'eleven_v3',                label: 'Eleven v3 (latest)',            noSpeed: true },
    { id: 'eleven_multilingual_v2',   label: 'Multilingual v2 (best quality)' },
    { id: 'eleven_turbo_v2_5',        label: 'Turbo v2.5 (low latency)' },
    { id: 'eleven_flash_v2_5',        label: 'Flash v2.5 (fastest)' },
    { id: 'eleven_monolingual_v1',    label: 'Monolingual v1 (English)',      noSpeed: true },
  ];

  // ─── Allowed voices — match by id (preferred) or name ───
  const ALLOWED_VOICES = [
    { name: 'Mark - ConvoAI' },
    { id: '8Ln42OXYupYsag45MAUy', name: 'Jey' },
    { name: 'Sienna - Natural and Bright' },
    { name: 'Annie - Bright, Clear, and Engaging' },
    { name: 'Liam - Energetic, Social Media Creator' },
    { id: 'UgBBYS2sOqTuMpoF3BR0', name: 'Mark - Dynamic, Balanced and Emotional' },
  ];

  // ─── State ───
  let apiKey = '';
  let voices = [];
  let isGenerating = false;
  let outputDir = (path && os) ? path.join(os.tmpdir(), 'elevenlabs-ae') : '/tmp/elevenlabs-ae';
  let history = [];
  let pptxSlides = null;          // cached slide list from last PPTX import
  let updateSourcePath = '';      // shared drive folder path configured by user
  let availableUpdateVersion = null; // set when a newer version is found

  // ─── DOM references ───
  const $ = id => document.getElementById(id);

  const el = {
    apiKeyInput:          $('api-key'),
    saveKeyBtn:           $('save-key-btn'),
    voiceSelect:          $('voice-select'),
    modelSelect:          $('model-select'),
    scriptText:           $('script-text'),
    charCount:            $('char-count'),
    stabilitySlider:      $('stability'),
    stabilityVal:         $('stability-val'),
    similaritySlider:     $('similarity'),
    similarityVal:        $('similarity-val'),
    speedSlider:          $('speed'),
    speedVal:             $('speed-val'),
    importPptxBtn:        $('import-pptx-btn'),
    slidePicker:          $('slide-picker'),
    slideList:            $('slide-list'),
    closeSlidePicker:     $('close-slide-picker'),
    reloadPptxBtn:        $('reload-pptx-btn'),
    importProgress:       $('import-progress'),
    importProgressFill:   $('import-progress-fill'),
    filenameInput:        $('filename-input'),
    autoSaveVo:           $('auto-save-vo'),
    saveSpecific:         $('save-specific'),
    specificFolderRow:    $('specific-folder-row'),
    outputPath:           $('output-path'),
    changePathBtn:        $('change-path-btn'),
    openFolderBtn:        $('open-folder-btn'),
    generateBtn:          $('generate-btn'),
    statusBar:            $('status-bar'),
    statusDot:            $('status-dot'),
    statusText:           $('status-text'),
    voiceSearch:          $('voice-search'),
    historyList:          $('history-list'),
    helpBtn:              $('help-btn'),
    helpPanel:            $('help-panel'),
    updateBtn:            $('update-btn'),
    updatePanel:          $('update-panel'),
    updateBadge:          $('update-badge'),
    updateSourceDisplay:  $('update-source-display'),
    updateBrowseBtn:      $('update-browse-btn'),
    checkUpdateBtn:       $('check-update-btn'),
    doUpdateBtn:          $('do-update-btn'),
    updateStatusText:     $('update-status-text'),
    historyToggle:        $('history-toggle'),
    historyArrow:         $('history-arrow'),
    historyBody:          $('history-body'),
  };


  // ─── Initialization ───
  function init() {
    loadSavedState();
    populateModels();
    bindEvents();
    ensureOutputDir();
    updateOutputPathDisplay();

    // Rename panel for Premiere Pro
    if (IS_PREMIERE) {
      document.title = '11Labs \u2192 Pr';
      const titleEl = document.querySelector('.header-title');
      if (titleEl) titleEl.textContent = '11Labs \u2192 Pr';
      const versionEl = document.querySelector('.header-version');
      if (versionEl) versionEl.title = 'Running in Adobe Premiere Pro';
    }

    // Manually load the JSX so it works reliably in both AE and Premiere.
    // Manifest-based ScriptPath is unreliable in Premiere Pro.
    loadJSX(() => {
      if (apiKey) {
        setStatus('loading', 'Fetching voices…');
        fetchVoices();
      } else {
        setStatus('idle', 'Enter your ElevenLabs API key to begin.');
      }
    });
  }

  function loadJSX(callback) {
    try {
      const extPath = cs.getSystemPath('EXTENSION');
      const jsxPath = path.join(extPath, 'jsx', 'hostscript.jsx');
      const jsxCode = fs.readFileSync(jsxPath, 'utf8');
      cs.evalScript(jsxCode, result => {
        if (result && result.startsWith('EvalScript')) {
          console.error('JSX eval failed:', result);
        }
        if (callback) callback();
      });
    } catch (e) {
      console.error('loadJSX error:', e.message);
      if (callback) callback();
    }
  }

  function loadSavedState() {
    apiKey = localStorage.getItem('el_api_key') || '';
    outputDir = localStorage.getItem('el_output_dir') || outputDir;
    updateSourcePath = localStorage.getItem('el_update_source') || '';
    if (el.updateSourceDisplay) {
      el.updateSourceDisplay.textContent = updateSourcePath || 'Not configured';
      el.updateSourceDisplay.title = updateSourcePath || '';
    }

    if (el.apiKeyInput) el.apiKeyInput.value = apiKey;

    const savedStability = localStorage.getItem('el_stability');
    const savedSimilarity = localStorage.getItem('el_similarity');
    const savedSpeed = localStorage.getItem('el_speed');

    if (savedStability) {
      el.stabilitySlider.value = savedStability;
      el.stabilityVal.textContent = savedStability;
    }
    if (savedSimilarity) {
      el.similaritySlider.value = savedSimilarity;
      el.similarityVal.textContent = savedSimilarity;
    }
    if (savedSpeed) {
      el.speedSlider.value = savedSpeed;
      el.speedVal.textContent = savedSpeed;
    }

    const savedAutoSave = localStorage.getItem('el_auto_save_vo');
    const savedSaveSpecific = localStorage.getItem('el_save_specific');
    el.autoSaveVo.checked = savedAutoSave !== null ? savedAutoSave === 'true' : true;
    el.saveSpecific.checked = savedSaveSpecific === 'true';
    updateSpecificFolderVisibility();

    const savedModel = localStorage.getItem('el_model');
    if (savedModel) {
      el.modelSelect.dataset.savedModel = savedModel;
    }

    const savedHistory = localStorage.getItem('el_history');
    if (savedHistory) {
      try { history = JSON.parse(savedHistory); } catch (_) {}
      renderHistory();
    }
  }

  function populateModels() {
    el.modelSelect.innerHTML = '';
    MODELS.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m.id;
      opt.textContent = m.label;
      el.modelSelect.appendChild(opt);
    });

    const saved = el.modelSelect.dataset.savedModel;
    if (saved) el.modelSelect.value = saved;
    updateSpeedState();
  }

  function updateSpeedState() {
    const modelId = el.modelSelect.value;
    const model = MODELS.find(m => m.id === modelId);
    const noSpeed = model && model.noSpeed;
    el.speedSlider.disabled = !!noSpeed;
    const hint = noSpeed ? 'Speed not supported by this model' : '';
    el.speedSlider.title = hint;
    el.speedVal.title = hint;
    el.speedVal.style.opacity = noSpeed ? '0.4' : '';
  }

  function bindEvents() {
    // API key
    el.saveKeyBtn.addEventListener('click', onSaveKey);
    el.apiKeyInput.addEventListener('keydown', e => {
      if (e.key === 'Enter') onSaveKey();
    });

    // Text area
    el.scriptText.addEventListener('input', updateCharCount);

    // Sliders
    el.stabilitySlider.addEventListener('input', () => {
      el.stabilityVal.textContent = el.stabilitySlider.value;
      localStorage.setItem('el_stability', el.stabilitySlider.value);
    });
    el.similaritySlider.addEventListener('input', () => {
      el.similarityVal.textContent = el.similaritySlider.value;
      localStorage.setItem('el_similarity', el.similaritySlider.value);
    });
    el.speedSlider.addEventListener('input', () => {
      el.speedVal.textContent = el.speedSlider.value;
      localStorage.setItem('el_speed', el.speedSlider.value);
    });

    // Model select
    el.modelSelect.addEventListener('change', () => {
      localStorage.setItem('el_model', el.modelSelect.value);
      updateSpeedState();
    });

    // Output folder checkboxes (mutually exclusive)
    el.autoSaveVo.addEventListener('change', () => {
      if (el.autoSaveVo.checked) {
        el.saveSpecific.checked = false;
        localStorage.setItem('el_save_specific', 'false');
      }
      localStorage.setItem('el_auto_save_vo', String(el.autoSaveVo.checked));
      updateSpecificFolderVisibility();
    });
    el.saveSpecific.addEventListener('change', () => {
      if (el.saveSpecific.checked) {
        el.autoSaveVo.checked = false;
        localStorage.setItem('el_auto_save_vo', 'false');
      }
      localStorage.setItem('el_save_specific', String(el.saveSpecific.checked));
      updateSpecificFolderVisibility();
    });

    // Output path
    el.changePathBtn.addEventListener('click', changeOutputDir);

    // Open saved folder
    el.openFolderBtn.addEventListener('click', async () => {
      try {
        const dir = await resolveOutputDir();
        openInFinder(dir);
      } catch (e) {
        setStatus('error', e.message);
      }
    });

    // PPTX import
    el.importPptxBtn.addEventListener('click', onImportPPTX);
    el.closeSlidePicker.addEventListener('click', () => {
      el.slidePicker.style.display = 'none';
    });
    el.reloadPptxBtn.addEventListener('click', () => {
      el.slidePicker.style.display = 'none';
      pptxSlides = null;
      onImportPPTX();
    });

    // Generate
    el.generateBtn.addEventListener('click', onGenerate);


    // Help panel toggle
    if (el.helpBtn) {
      el.helpBtn.addEventListener('click', () => {
        const open = el.helpPanel.classList.contains('visible');
        el.updatePanel.classList.remove('visible');
        el.updateBtn.classList.remove('active');
        el.helpPanel.classList.toggle('visible', !open);
        el.helpBtn.classList.toggle('active', !open);
      });
    }

    // Update panel toggle
    if (el.updateBtn) {
      el.updateBtn.addEventListener('click', () => {
        const open = el.updatePanel.classList.contains('visible');
        el.helpPanel.classList.remove('visible');
        el.helpBtn.classList.remove('active');
        el.updatePanel.classList.toggle('visible', !open);
        el.updateBtn.classList.toggle('active', !open);
      });
    }

    // Update badge → open update panel
    if (el.updateBadge) {
      el.updateBadge.addEventListener('click', () => {
        if (!el.updatePanel.classList.contains('visible')) el.updateBtn.click();
        setTimeout(() => {
          if (el.updateStatusText) el.updateStatusText.scrollIntoView({ behavior: 'smooth' });
        }, 50);
      });
    }

    // Update actions
    if (el.updateBrowseBtn) el.updateBrowseBtn.addEventListener('click', browseUpdateSource);
    if (el.checkUpdateBtn)  el.checkUpdateBtn.addEventListener('click', () => checkForUpdates());
    if (el.doUpdateBtn)     el.doUpdateBtn.addEventListener('click', doUpdate);

    // History toggle
    if (el.historyToggle) {
      el.historyToggle.addEventListener('click', () => {
        const isOpen = el.historyBody.style.maxHeight !== '0px';
        if (isOpen) {
          el.historyBody.style.maxHeight = '0px';
          el.historyArrow.style.transform = 'rotate(-90deg)';
        } else {
          el.historyBody.style.maxHeight = el.historyBody.scrollHeight + 'px';
          el.historyArrow.style.transform = '';
        }
      });
    }
  }

  // ─── API key ───
  function onSaveKey() {
    const key = el.apiKeyInput.value.trim();
    if (!key) {
      setStatus('error', 'Please enter a valid API key.');
      return;
    }
    apiKey = key;
    localStorage.setItem('el_api_key', apiKey);
    setStatus('loading', 'Fetching voices…');
    fetchVoices();
  }

  // ─── Fetch voices ───
  async function fetchVoices() {
    try {
      const res = await fetch(`${API_BASE}/voices`, {
        headers: { 'xi-api-key': apiKey }
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.detail?.message || `HTTP ${res.status}`);
      }

      const data = await res.json();
      voices = data.voices || [];

      populateVoiceDropdown();
      setStatus('success', `${voices.length} voices loaded. Ready to generate.`);

    } catch (e) {
      setStatus('error', `Failed to load voices: ${e.message}`);
      el.voiceSelect.innerHTML = '<option value="">— Load failed —</option>';
      el.voiceSelect.disabled = true;
    }
  }

  function populateVoiceDropdown(filter) {
    const savedVoice = localStorage.getItem('el_voice_id');
    const currentVoice = el.voiceSelect.value || savedVoice;

    el.voiceSelect.innerHTML = '';
    el.voiceSelect.disabled = false;

    const allowed = voices.filter(v =>
      ALLOWED_VOICES.some(a =>
        (a.id && a.id === v.voice_id) ||
        a.name.toLowerCase().trim() === v.name.toLowerCase().trim()
      )
    );
    const query = (filter || '').toLowerCase();
    const filtered = query
      ? allowed.filter(v => v.name.toLowerCase().includes(query))
      : allowed;

    filtered.forEach(v => {
      const opt = document.createElement('option');
      opt.value = v.voice_id;
      opt.textContent = `${v.name}${v.labels?.accent ? ` (${v.labels.accent})` : ''}`;
      el.voiceSelect.appendChild(opt);
    });

    if (currentVoice && filtered.some(v => v.voice_id === currentVoice)) {
      el.voiceSelect.value = currentVoice;
    }

    // Show search input once voices are available
    if (el.voiceSearch) {
      el.voiceSearch.style.display = '';
      if (!el.voiceSearch._bound) {
        el.voiceSearch._bound = true;
        el.voiceSearch.addEventListener('input', () => {
          populateVoiceDropdown(el.voiceSearch.value);
        });
      }
    }

    el.voiceSelect.addEventListener('change', () => {
      localStorage.setItem('el_voice_id', el.voiceSelect.value);
    });
  }

  // ─── Generate ───
  async function onGenerate() {
    if (isGenerating) return;

    const text = el.scriptText.value.trim();
    if (!text) {
      setStatus('error', 'Please enter some text to synthesize.');
      return;
    }

    const voiceId = el.voiceSelect.value;
    if (!voiceId) {
      setStatus('error', 'Please select a voice.');
      return;
    }

    if (!apiKey) {
      setStatus('error', 'Please save your API key first.');
      return;
    }

    isGenerating = true;
    el.generateBtn.disabled = true;
    setStatus('loading', 'Generating audio…');

    try {
      const audioBuffer = await callTTS(text, voiceId);
      let filePath = await saveAudioFile(audioBuffer, voiceId);


      await importIntoAE(filePath, voiceId, text);

    } catch (e) {
      setStatus('error', e.message);
    } finally {
      isGenerating = false;
      el.generateBtn.disabled = false;
    }
  }

  async function callTTS(text, voiceId) {
    const stability = parseFloat(el.stabilitySlider.value);
    const similarity = parseFloat(el.similaritySlider.value);
    const modelId = el.modelSelect.value;
    const model = MODELS.find(m => m.id === modelId);
    const speed = (!model || !model.noSpeed) ? parseFloat(el.speedSlider.value) : undefined;

    setStatus('loading', 'Calling ElevenLabs API…');

    const res = await fetch(`${API_BASE}/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
        'Accept': 'audio/mpeg',
      },
      body: JSON.stringify({
        text,
        model_id: modelId,
        voice_settings: {
          stability,
          similarity_boost: similarity,
          speed,
        },
      }),
    });

    if (!res.ok) {
      const errBody = await res.json().catch(() => ({}));
      const msg = errBody.detail?.message || errBody.detail || `HTTP ${res.status}`;
      throw new Error(`ElevenLabs error: ${msg}`);
    }

    const arrayBuf = await res.arrayBuffer();
    return Buffer.from(arrayBuf);
  }

  async function saveAudioFile(buffer, voiceId) {
    setStatus('loading', 'Saving audio file…');

    const dir = await resolveOutputDir();
    const timestamp = Date.now();
    const voiceName = (voices.find(v => v.voice_id === voiceId)?.name || 'voice')
      .replace(/[^a-zA-Z0-9_-]/g, '_');

    const customName = el.filenameInput ? el.filenameInput.value.trim() : '';
    let fileName;
    if (customName) {
      // Sanitize and ensure .mp3 extension
      fileName = customName.replace(/[/\\:*?"<>|]/g, '_');
      if (!fileName.toLowerCase().endsWith('.mp3')) fileName += '.mp3';
    } else {
      fileName = `EL_${voiceName}_${timestamp}.mp3`;
    }

    const filePath = path.join(dir, fileName);

    return new Promise((resolve, reject) => {
      fs.writeFile(filePath, buffer, err => {
        if (err) reject(new Error(`Failed to save audio: ${err.message}`));
        else resolve(filePath);
      });
    });
  }

  async function importIntoAE(filePath, voiceId, text) {
    setStatus('loading', 'Importing into timeline…');

    // Escape backslashes for ExtendScript string safety
    const escapedPath = filePath.replace(/\\/g, '\\\\').replace(/"/g, '\\"');

    return new Promise((resolve, reject) => {
      cs.evalScript(`importAndPlaceAudio("${escapedPath}")`, result => {
        if (!result || result.startsWith('ERROR:') || result.startsWith('EvalScript')) {
          reject(new Error(result ? result.replace('ERROR:', '').trim() : 'Unknown error'));
          return;
        }
        const layerName = result.replace('OK:', '');
        addToHistory(voiceId, text, filePath, layerName);
        setStatus('success', `Placed "${layerName}" on timeline.`);
        resolve();
      });
    });
  }


  // ─── PPTX import ───
  // Uses AE's native File.openDialog() via ExtendScript — works in all AE versions.
  function onImportPPTX() {
    // If slides are already loaded, just reopen the picker
    if (pptxSlides) {
      el.slidePicker.style.display = 'flex';
      return;
    }

    setStatus('loading', 'Opening file picker…');
    cs.evalScript('selectPPTXFile()', result => {
      if (!result || result === 'CANCELLED' || result.trim() === '') {
        setStatus('idle', 'No file selected.');
        return;
      }
      if (result.startsWith('ERROR:')) {
        setStatus('error', 'File picker error: ' + result.replace('ERROR:', '').trim());
        return;
      }
      const pptxPath = result.replace('OK:', '').trim();
      if (!pptxPath.toLowerCase().endsWith('.pptx')) {
        setStatus('error', 'Please select a .pptx file.');
        return;
      }
      setStatus('loading', 'Reading PPTX…');
      parsePPTX(pptxPath);
    });
  }

  // Shell-safe single-quote wrapper
  const sq = p => "'" + p.replace(/'/g, "'\\''") + "'";

  async function parsePPTX(pptxPath) {
    // Extract PPTX contents (it's a ZIP) to a temp dir using system unzip.
    // This avoids a manual JS ZIP parser and is reliable across all PPTX variants.
    const tmpDir = path.join(os.tmpdir(), 'el_pptx_' + Date.now());

    try {
      fs.mkdirSync(tmpDir, { recursive: true });

      // Extract slides, rels, and notes in one shot.
      // unzip exits non-zero if some glob patterns match nothing — that's fine.
      try {
        childProcess.execSync(
          `unzip -q ${sq(pptxPath)} 'ppt/slides/*.xml' 'ppt/slides/_rels/*.rels' 'ppt/notesSlides/*.xml' -d ${sq(tmpDir)}`,
          { timeout: 15000 }
        );
      } catch (_) { /* exit 11 = pattern matched nothing — acceptable */ }

      const slidesDir = path.join(tmpDir, 'ppt', 'slides');
      if (!fs.existsSync(slidesDir)) {
        setStatus('error', 'No slides found in this PPTX file.');
        return;
      }

      const slideNums = fs.readdirSync(slidesDir)
        .filter(f => /^slide\d+\.xml$/.test(f))
        .map(f => parseInt(f.match(/\d+/)[0]))
        .sort((a, b) => a - b);

      if (slideNums.length === 0) {
        setStatus('error', 'No slides found in this PPTX file.');
        return;
      }

      showImportProgress(0);
      const slides = [];

      for (let i = 0; i < slideNums.length; i++) {
        const n = slideNums[i];
        setStatus('loading', `Reading slide ${i + 1} / ${slideNums.length}…`);
        showImportProgress(Math.round((i / slideNums.length) * 100));
        await new Promise(r => setTimeout(r, 0));

        // Slide title
        let title = '';
        try {
          const xml = fs.readFileSync(path.join(slidesDir, `slide${n}.xml`), 'utf8');
          title = extractSlideTitle(xml);
        } catch (_) {}

        // Notes — use .rels file to find the correct notesSlide file number
        let notes = '';
        try {
          let notesFile = `notesSlide${n}.xml`;
          const relsPath = path.join(slidesDir, '_rels', `slide${n}.xml.rels`);
          if (fs.existsSync(relsPath)) {
            const relsXml = fs.readFileSync(relsPath, 'utf8');
            const m = relsXml.match(/Target="\.\.\/notesSlides\/(notesSlide\d+\.xml)"/);
            if (m) notesFile = m[1];
          }
          const notesFilePath = path.join(tmpDir, 'ppt', 'notesSlides', notesFile);
          if (fs.existsSync(notesFilePath)) {
            const notesXml = fs.readFileSync(notesFilePath, 'utf8');
            notes = extractSlideNotes(notesXml);
          }
        } catch (_) {}

        slides.push({ num: n, title, notes });
      }

      showImportProgress(100);
      setTimeout(() => hideImportProgress(), 600);

      pptxSlides = slides;
      renderSlidePicker(slides);
      setStatus('idle', `${slides.length} slides loaded — click one to use its notes.`);

    } catch (e) {
      hideImportProgress();
      setStatus('error', 'Failed to parse PPTX: ' + e.message);
    } finally {
      try { childProcess.execSync(`rm -rf ${sq(tmpDir)}`, { timeout: 3000 }); } catch (_) {}
    }
  }

  function extractSlideTitle(xml) {
    const match = xml.match(/<p:ph[^>]*type="(?:title|ctrTitle)"[^>]*\/?>/);
    if (!match) return '';
    const spStart = xml.lastIndexOf('<p:sp>', match.index);
    const spEnd   = xml.indexOf('</p:sp>', match.index);
    if (spStart < 0 || spEnd < 0) return '';
    return extractXmlText(xml.slice(spStart, spEnd + 7));
  }

  function extractSlideNotes(xml) {
    // The notes body shape has idx="1"; the slide-image shape has idx="0" (no text).
    // Safest approach: find idx="1" shape and extract its text.
    // Fall back to full-XML extraction if shape isn't found.
    const match = xml.match(/<p:ph[^>]*idx="1"[^>]*\/?>/i);
    if (match) {
      const spStart = xml.lastIndexOf('<p:sp>', match.index);
      const spEnd   = xml.indexOf('</p:sp>', match.index);
      if (spStart >= 0 && spEnd >= 0) {
        return extractXmlText(xml.slice(spStart, spEnd + 7)).trim();
      }
    }
    // Fallback: all text in the notes XML (idx="0" shapes rarely carry <a:t> text)
    return extractXmlText(xml).trim();
  }

  function extractXmlText(xml) {
    const texts = [];
    const re = /<a:t[^>]*>([^<]*)<\/a:t>/g;
    let m;
    while ((m = re.exec(xml)) !== null) {
      const t = decodeXmlEntities(m[1]).trim();
      if (t) texts.push(t);
    }
    return texts.join(' ');
  }

  function decodeXmlEntities(str) {
    return str
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&apos;/g, "'")
      .replace(/&quot;/g, '"')
      .replace(/&#xD;|&#x0D;/g, '');
  }

  function escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function renderSlidePicker(slides) {
    el.slideList.innerHTML = '';

    slides.forEach(slide => {
      const card = document.createElement('div');
      card.className = 'slide-card' + (slide.notes ? '' : ' slide-card--no-notes');

      const titleHtml = slide.title
        ? `<span class="slide-title-text">${escapeHtml(slide.title)}</span>`
        : '';

      const notesHtml = slide.notes
        ? `<div class="slide-notes-text">${escapeHtml(slide.notes)}</div>`
        : '<span class="slide-no-notes">No speaker notes</span>';

      card.innerHTML = `
        <div class="slide-card-header">
          <span class="slide-num-badge">Slide ${slide.num}</span>
          ${titleHtml}
        </div>
        ${notesHtml}
      `;

      card.addEventListener('click', () => {
        if (slide.notes) {
          el.scriptText.value = slide.notes;
          updateCharCount();
          setStatus('idle', `Slide ${slide.num} notes loaded.`);
        } else {
          setStatus('warning', `Slide ${slide.num} has no speaker notes.`);
        }
        el.slidePicker.style.display = 'none';
      });

      el.slideList.appendChild(card);
    });

    el.slidePicker.style.display = 'flex';
  }

  // ─── Open folder in Finder / Explorer ───
  function openInFinder(folderPath) {
    if (!childProcess) return;
    const cmd = os.platform() === 'win32'
      ? `explorer "${folderPath.replace(/\//g, '\\')}"`
      : `open "${folderPath}"`;
    childProcess.exec(cmd);
  }

  // ─── Output folder helpers ───
  function updateSpecificFolderVisibility() {
    el.specificFolderRow.style.display = el.saveSpecific.checked ? 'flex' : 'none';
  }

  function resolveOutputDir() {
    if (!el.autoSaveVo.checked) {
      ensureOutputDir();
      return Promise.resolve(outputDir);
    }

    return new Promise((resolve) => {
      const fallbackToDesktop = (reason) => {
        const desktop = path.join(os.homedir(), 'Desktop');
        setStatus('warning', reason + ' — saving to Desktop.');
        resolve(desktop);
      };

      cs.evalScript('getProjectFolder()', result => {
        if (!result || result.startsWith('ERROR:')) {
          fallbackToDesktop(result ? result.replace('ERROR:', '').trim() : 'Could not get project folder');
          return;
        }

        const rootFolder = result.replace('OK:', '').trim();
        const voFolder = path.join(rootFolder, 'Footage', 'Audio', 'VO');

        if (!fs.existsSync(voFolder)) {
          fallbackToDesktop('VO folder not found');
          return;
        }

        resolve(voFolder);
      });
    });
  }

  // ─── Output directory ───
  function ensureOutputDir() {
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
  }

  function updateOutputPathDisplay() {
    el.outputPath.textContent = outputDir;
    el.outputPath.title = outputDir;
  }

  function changeOutputDir() {
    const result = window.cep.fs.showOpenDialogEx(
      false, true, 'Choose output folder', outputDir, []
    );

    if (result && result.data && result.data.length > 0) {
      outputDir = result.data[0];
      localStorage.setItem('el_output_dir', outputDir);
      ensureOutputDir();
      updateOutputPathDisplay();
    }
  }

  // ─── History ───
  function addToHistory(voiceId, text, filePath, layerName) {
    const voiceName = voices.find(v => v.voice_id === voiceId)?.name || voiceId;
    const item = {
      voiceName,
      text: text.slice(0, 60) + (text.length > 60 ? '…' : ''),
      filePath,
      layerName,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    history.unshift(item);
    if (history.length > 10) history.pop();
    localStorage.setItem('el_history', JSON.stringify(history));
    renderHistory();
    // Auto-expand history section on new generation
    if (el.historyBody && el.historyBody.style.maxHeight === '0px') {
      el.historyBody.style.maxHeight = el.historyBody.scrollHeight + 'px';
      if (el.historyArrow) el.historyArrow.style.transform = '';
    }
  }

  function renderHistory() {
    if (!el.historyList) return;
    el.historyList.innerHTML = '';

    if (history.length === 0) {
      el.historyList.innerHTML = '<div style="color:var(--text-muted);font-size:11px;padding:4px 0">No generations yet.</div>';
      return;
    }

    history.forEach(item => {
      const div = document.createElement('div');
      div.className = 'history-item';
      div.title = item.filePath ? 'Click to reveal in Finder' : '';
      div.innerHTML = `
        <span class="history-voice">${item.voiceName}</span>
        <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${item.text}</span>
        <span class="history-time">${item.time}</span>
      `;
      if (item.filePath) {
        div.style.cursor = 'pointer';
        div.addEventListener('click', () => revealInFinder(item.filePath));
      }
      el.historyList.appendChild(div);
    });
  }

  function revealInFinder(filePath) {
    if (!filePath || !childProcess) return;
    const isWin = os.platform() === 'win32';
    if (isWin) {
      childProcess.exec(`explorer /select,"${filePath}"`);
    } else {
      childProcess.exec(`open -R ${sq(filePath)}`);
    }
  }

  // ─── Character count ───
  function updateCharCount() {
    const len = el.scriptText.value.length;
    const max = 5000;
    el.charCount.textContent = `${len} / ${max}`;
    el.charCount.classList.toggle('warn', len > max * 0.9);
    if (len > max) {
      el.scriptText.value = el.scriptText.value.slice(0, max);
    }
  }

  // ─── Import progress bar ───
  function showImportProgress(pct) {
    if (!el.importProgress) return;
    el.importProgress.style.display = 'block';
    el.importProgressFill.style.width = Math.min(100, pct) + '%';
  }

  function hideImportProgress() {
    if (!el.importProgress) return;
    el.importProgress.style.display = 'none';
    el.importProgressFill.style.width = '0%';
  }

  // ─── Update ───

  function getCurrentVersion() {
    try {
      const extPath = cs.getSystemPath(SystemPath.EXTENSION);
      const manifestPath = path.join(extPath, 'CSXS', 'manifest.xml');
      const xml = fs.readFileSync(manifestPath, 'utf8');
      const m = xml.match(/ExtensionBundleVersion="([^"]+)"/);
      return m ? m[1] : '0.0.0';
    } catch (_) { return '0.0.0'; }
  }

  function versionGt(a, b) {
    const parse = v => v.split('.').map(n => parseInt(n) || 0);
    const [a1, a2, a3] = parse(a);
    const [b1, b2, b3] = parse(b);
    if (a1 !== b1) return a1 > b1;
    if (a2 !== b2) return a2 > b2;
    return a3 > b3;
  }

  function setUpdateStatus(msg) {
    if (el.updateStatusText) el.updateStatusText.textContent = msg;
  }

  function showUpdateBadge(remoteVer) {
    if (el.updateBadge) {
      el.updateBadge.textContent = `↑ v${remoteVer}`;
      el.updateBadge.style.display = 'inline-block';
    }
    if (el.doUpdateBtn) {
      el.doUpdateBtn.textContent = `↑ Install v${remoteVer}`;
      el.doUpdateBtn.style.display = 'block';
      el.doUpdateBtn.disabled = false;
    }
  }

  function hideUpdateBadge() {
    if (el.updateBadge) el.updateBadge.style.display = 'none';
    if (el.doUpdateBtn) el.doUpdateBtn.style.display = 'none';
  }

  function checkForUpdates() {
    if (!updateSourcePath) {
      setUpdateStatus('No update folder configured — click Browse… to set it.');
      return;
    }
    if (!fs.existsSync(updateSourcePath)) {
      setUpdateStatus('Update folder not found: ' + updateSourcePath);
      return;
    }
    const versionFile = path.join(updateSourcePath, 'version.txt');
    if (!fs.existsSync(versionFile)) {
      setUpdateStatus('No version.txt found in update folder.');
      return;
    }
    try {
      const remoteVersion = fs.readFileSync(versionFile, 'utf8').trim();
      const currentVersion = getCurrentVersion();
      if (versionGt(remoteVersion, currentVersion)) {
        availableUpdateVersion = remoteVersion;
        showUpdateBadge(remoteVersion);
        setUpdateStatus(`Update available: v${currentVersion} → v${remoteVersion}`);
      } else {
        availableUpdateVersion = null;
        hideUpdateBadge();
        setUpdateStatus(`You're up to date (v${currentVersion}).`);
      }
    } catch (e) {
      setUpdateStatus('Error checking version: ' + e.message);
    }
  }

  function browseUpdateSource() {
    cs.evalScript('selectFolder()', result => {
      if (!result || result === 'CANCELLED' || result.trim() === '') return;
      if (result.startsWith('ERROR:')) {
        setUpdateStatus('Folder picker error: ' + result.replace('ERROR:', '').trim());
        return;
      }
      const folderPath = result.replace('OK:', '').trim();
      updateSourcePath = folderPath;
      localStorage.setItem('el_update_source', updateSourcePath);
      if (el.updateSourceDisplay) {
        el.updateSourceDisplay.textContent = updateSourcePath;
        el.updateSourceDisplay.title = updateSourcePath;
      }
      setUpdateStatus('Folder set. Click "Check for Updates".');
    });
  }

  async function doUpdate() {
    if (!availableUpdateVersion || !updateSourcePath) return;

    const targetVersion = availableUpdateVersion;
    const srcZip = path.join(updateSourcePath, '11Labs to AE.zip');

    if (!fs.existsSync(srcZip)) {
      setUpdateStatus(`ZIP not found in update folder: 11Labs to AE.zip`);
      return;
    }

    el.doUpdateBtn.disabled = true;
    el.doUpdateBtn.textContent = 'Installing…';
    setUpdateStatus('Copying update…');

    const isWin = os.platform() === 'win32';
    const tmpZip = path.join(os.tmpdir(), `el_update_${Date.now()}.zip`);
    const tmpDir = tmpZip.replace('.zip', '_extracted');

    try {
      fs.copyFileSync(srcZip, tmpZip);
      setUpdateStatus('Extracting…');

      fs.mkdirSync(tmpDir, { recursive: true });
      if (isWin) {
        childProcess.execSync(
          `powershell -command "Expand-Archive -Path '${tmpZip.replace(/'/g, "''")}' -DestinationPath '${tmpDir.replace(/'/g, "''")}' -Force"`,
          { timeout: 30000 }
        );
      } else {
        childProcess.execSync(`unzip -q ${sq(tmpZip)} -d ${sq(tmpDir)}`, { timeout: 30000 });
      }

      const entries = fs.readdirSync(tmpDir);
      const pluginFolder = entries.find(e =>
        fs.statSync(path.join(tmpDir, e)).isDirectory() &&
        fs.existsSync(path.join(tmpDir, e, 'CSXS', 'manifest.xml'))
      );
      if (!pluginFolder) throw new Error('Plugin folder not found inside ZIP.');

      const srcPluginPath = path.join(tmpDir, pluginFolder);
      const installedPath = cs.getSystemPath(SystemPath.EXTENSION);
      setUpdateStatus('Installing…');

      if (isWin) {
        childProcess.execSync(`rmdir /s /q "${installedPath}"`, { timeout: 10000 });
        childProcess.execSync(`xcopy /e /i /q "${srcPluginPath}" "${installedPath}\\"`, { timeout: 15000 });
      } else {
        childProcess.execSync(`rm -rf ${sq(installedPath)}`, { timeout: 10000 });
        childProcess.execSync(`cp -r ${sq(srcPluginPath)} ${sq(installedPath)}`, { timeout: 15000 });
      }

      for (const v of [9, 10, 11, 12]) {
        try {
          if (isWin) {
            childProcess.execSync(`reg add "HKCU\\SOFTWARE\\Adobe\\CSXS.${v}" /v PlayerDebugMode /t REG_SZ /d 1 /f`, { timeout: 3000 });
          } else {
            childProcess.execSync(`defaults write com.adobe.CSXS.${v} PlayerDebugMode 1`, { timeout: 3000 });
          }
        } catch (_) {}
      }

      availableUpdateVersion = null;
      hideUpdateBadge();
      setUpdateStatus(`✓ Updated to v${targetVersion}. Restart After Effects to apply.`);
      setStatus('success', `Plugin updated to v${targetVersion} — please restart After Effects.`);

    } catch (e) {
      el.doUpdateBtn.disabled = false;
      el.doUpdateBtn.textContent = `↑ Install v${targetVersion}`;
      setUpdateStatus('Update failed: ' + e.message);
      setStatus('error', 'Update failed: ' + e.message);
    } finally {
      try { fs.unlinkSync(tmpZip); } catch (_) {}
      try {
        if (isWin) childProcess.execSync(`rmdir /s /q "${tmpDir}"`, { timeout: 5000 });
        else childProcess.execSync(`rm -rf ${sq(tmpDir)}`, { timeout: 5000 });
      } catch (_) {}
    }
  }

  // ─── Status bar ───
  function setStatus(type, message) {
    el.statusBar.className = `status-bar ${type}`;
    el.statusText.textContent = message;
  }

  // ─── Boot ───
  document.addEventListener('DOMContentLoaded', init);

})();
