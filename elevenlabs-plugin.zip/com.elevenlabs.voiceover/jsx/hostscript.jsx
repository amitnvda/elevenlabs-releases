/**
 * ElevenLabs Voiceover - ExtendScript
 * Handles audio import and timeline placement for After Effects and Premiere Pro.
 */

// --- Ping (diagnostic) ---
function pingJSX() {
    return "OK:alive";
}

// --- App detection: CompItem only exists in After Effects ---
function isPremiereHost() {
    return (typeof CompItem === "undefined");
}

/**
 * Unified entry point -- routes to the correct host implementation.
 * @param {string} filePath - Absolute path to the .mp3 file
 * @returns {string} "OK:<layerName>" on success, "ERROR:<message>" on failure
 */
function importAndPlaceAudio(filePath) {
    if (isPremiereHost()) {
        return importAndPlaceAudioPremiere(filePath);
    } else {
        return importAndPlaceAudioAE(filePath);
    }
}

/**
 * After Effects: import audio and place at playhead in active comp.
 */
function importAndPlaceAudioAE(filePath) {
    try {
        var audioFile = new File(filePath);
        if (!audioFile.exists) return "ERROR:File not found: " + filePath;

        var comp = app.project.activeItem;
        if (typeof CompItem === "undefined" || !(comp instanceof CompItem)) {
            return "ERROR:No active composition. Please open a composition first.";
        }

        var importOptions = new ImportOptions(audioFile);
        importOptions.sequence = false;
        importOptions.forceAlphabetical = false;

        var audioItem = app.project.importFile(importOptions);

        app.beginUndoGroup("ElevenLabs Voiceover");
        var layer = comp.layers.add(audioItem);
        layer.startTime = comp.time;
        layer.name = "EL: " + audioItem.name;
        app.endUndoGroup();

        return "OK:" + layer.name;
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Premiere Pro: import audio and insert at playhead on the first audio track.
 */
function importAndPlaceAudioPremiere(filePath) {
    var log = [];
    try {
        // 1. File check
        var audioFile = new File(filePath);
        if (!audioFile.exists) return "ERROR:File not found: " + filePath;
        log.push("file:ok");

        // 2. Enable QE engine
        try { app.enableQE(); log.push("qe:ok"); } catch(qeErr) { log.push("qe:fail=" + qeErr.message); }

        // 3. Sequence check
        var seq = app.project.activeSequence;
        if (!seq) return "ERROR:No active sequence -- open a sequence first.";
        log.push("seq:" + seq.name);

        // 4. Find or create VO bin
        var root  = app.project.rootItem;
        var voBin = null;
        for (var i = 0; i < root.children.numItems; i++) {
            if (root.children[i].name === "VO") { voBin = root.children[i]; break; }
        }
        if (!voBin) voBin = root.createBin("VO");
        log.push("bin:ok");

        // 5. Import
        var countBefore = voBin.children.numItems;
        app.project.importFiles([filePath], true, voBin, false);
        log.push("imported:before=" + countBefore + ",after=" + voBin.children.numItems);

        // 6. Find item
        var fileName     = audioFile.name;
        var fileNameBase = fileName.replace(/\.[^.]+$/, "");
        var projectItem  = null;
        for (var j = 0; j < voBin.children.numItems; j++) {
            var n = voBin.children[j].name;
            if (n === fileName || n === fileNameBase) { projectItem = voBin.children[j]; break; }
        }
        if (!projectItem && voBin.children.numItems > countBefore) {
            projectItem = voBin.children[voBin.children.numItems - 1];
        }
        if (!projectItem) return "ERROR:[" + log.join(",") + "] item not found in bin";
        log.push("item:" + projectItem.name + ",type:" + projectItem.type);

        // 7. Get playhead position
        var ticks = "0";
        var secs  = 0;
        try {
            var pos = seq.getPlayerPosition();
            ticks = pos.ticks;
            secs  = pos.seconds;
        } catch(posErr) { log.push("pos:fail=" + posErr.message); }
        log.push("time:ticks=" + ticks + ",secs=" + secs);

        // 8. Insert -- try three methods
        try {
            seq.insertClip(projectItem, ticks, -1, 0);
            log.push("insert1:ok");
            return "OK:[" + log.join(",") + "] EL: " + projectItem.name;
        } catch (e1) { log.push("insert1:fail=" + e1.message); }

        try {
            seq.audioTracks[0].insertClip(projectItem, ticks);
            log.push("insert2:ok");
            return "OK:[" + log.join(",") + "] EL: " + projectItem.name;
        } catch (e2) { log.push("insert2:fail=" + e2.message); }

        try {
            seq.insertClip(projectItem, secs, -1, 0);
            log.push("insert3:ok");
            return "OK:[" + log.join(",") + "] EL: " + projectItem.name;
        } catch (e3) { log.push("insert3:fail=" + e3.message); }

        return "ERROR:[" + log.join(",") + "]";

    } catch (e) {
        return "ERROR:[" + log.join(",") + "] " + e.message;
    }
}

/**
 * Returns basic info about the active composition.
 * @returns {string} JSON-encoded comp info, or "ERROR:<message>"
 */
function getCompInfo() {
    try {
        var comp = app.project.activeItem;
        if (typeof CompItem === "undefined" || !(comp instanceof CompItem)) {
            return "ERROR:No active composition";
        }
        return JSON.stringify({
            name: comp.name,
            duration: comp.duration,
            frameRate: comp.frameRate,
            currentTime: comp.time
        });
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Returns the project folder path.
 * AE: walks up from .aep to find a folder containing "Footage".
 * Premiere: returns the folder containing the .prproj file.
 * @returns {string} "OK:<folderPath>" or "ERROR:<message>"
 */
function getProjectFolder() {
    try {
        if (!app.project.file) {
            var appLabel = isPremiereHost() ? "Premiere" : "After Effects";
            return "ERROR:Project not saved. Please save your " + appLabel + " project first.";
        }

        if (isPremiereHost()) {
            return "OK:" + app.project.file.parent.fsName;
        }

        // AE: walk up from .aep to find a folder that contains "Footage"
        var folder = app.project.file.parent;
        var maxLevels = 6;
        while (maxLevels-- > 0) {
            var footage = new Folder(folder.fsName + "/Footage");
            if (footage.exists) {
                return "OK:" + folder.fsName;
            }
            if (!folder.parent) break;
            folder = folder.parent;
        }
        return "ERROR:Could not find a parent folder containing a 'Footage' subfolder.";
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Opens the host's native file picker for selecting a PPTX file.
 * @returns {string} "OK:<fsPath>" or "CANCELLED"
 */
function selectPPTXFile() {
    try {
        var f = File.openDialog("Select a PPTX file", "PPTX Files:*.pptx,All Files:*.*");
        if (!f) return "CANCELLED";
        return "OK:" + f.fsName;
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Opens the host's native folder picker.
 * @returns {string} "OK:<fsPath>" or "CANCELLED" or "ERROR:<message>"
 */
function selectFolder() {
    try {
        var f = Folder.selectDialog("Select update source folder");
        if (!f) return "CANCELLED";
        return "OK:" + f.fsName;
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Returns the current playhead time (in seconds).
 * @returns {string} time as string, or "ERROR:<message>"
 */
function getCurrentTime() {
    try {
        if (isPremiereHost()) {
            var seq = app.project.activeSequence;
            if (!seq) return "ERROR:No active sequence";
            return String(seq.getPlayerPosition().seconds);
        }
        var comp = app.project.activeItem;
        if (typeof CompItem === "undefined" || !(comp instanceof CompItem)) return "ERROR:No active composition";
        return String(comp.time);
    } catch (e) {
        return "ERROR:" + e.message;
    }
}
