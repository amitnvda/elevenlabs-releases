@echo off
:: ElevenLabs Voiceover — Windows Installer
:: Run as Administrator for best results.

setlocal enabledelayedexpansion

set PLUGIN_NAME=com.elevenlabs.voiceover
set SCRIPT_DIR=%~dp0
set INSTALL_DIR=%APPDATA%\Adobe\CEP\extensions\%PLUGIN_NAME%

echo.
echo   ElevenLabs Voiceover -- After Effects Plugin Installer
echo   --------------------------------------------------------
echo.

:: ── 1. Enable CEP debug mode ──
echo   [1/3] Enabling CEP debug mode...
reg add "HKCU\SOFTWARE\Adobe\CSXS.9"  /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\SOFTWARE\Adobe\CSXS.10" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\SOFTWARE\Adobe\CSXS.11" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
reg add "HKCU\SOFTWARE\Adobe\CSXS.12" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
echo         Done.

:: ── 2. Install plugin ──
echo   [2/3] Installing plugin...
if not exist "%APPDATA%\Adobe\CEP\extensions" (
  mkdir "%APPDATA%\Adobe\CEP\extensions"
)

if exist "%INSTALL_DIR%" (
  rmdir /s /q "%INSTALL_DIR%"
)

xcopy /e /i /q "%SCRIPT_DIR%" "%INSTALL_DIR%\" >nul
echo         Installed to: %INSTALL_DIR%

:: ── 3. Verify ──
echo   [3/3] Verifying...
if exist "%INSTALL_DIR%\CSXS\manifest.xml" (
  echo         OK -- manifest found.
) else (
  echo         ERROR: manifest.xml missing. Something went wrong.
  pause
  exit /b 1
)

echo.
echo   Installation complete!
echo.
echo   Next steps:
echo     1. Restart After Effects (fully quit and reopen)
echo     2. Go to  Window ^> Extensions ^> 11Labs -> AE
echo     3. Enter your ElevenLabs API key and click Save
echo.
pause
