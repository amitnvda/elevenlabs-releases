/**
 * ElevenLabs Voiceover Panel - Main Logic
 * Handles API communication, file I/O, and ExtendScript bridge.
 */

/* global CSInterface */

(function () {
  'use strict';

  // ─── Node.js modules ───
  const _require = (typeof window.cep_node !== 'undefined')
    ? window.cep_node.require.bind(window.cep_node)
    : (typeof require !== 'undefined' ? require : null);

  if (!_require) {
    console.error('Node.js is not available in this CEP context. Check --enable-nodejs flag.');
  }

  const fs           = _require && _require('fs');
  const path         = _require && _require('path');
  const os           = _require && _require('os');
  const childProcess = _require && _require('child_process');
  const Buffer = (typeof window.cep_node !== 'undefined')
    ? window.cep_node.Buffer
    : (typeof Buffer !== 'undefined' ? Buffer : null);

  // ─── CEP bridge ───
  const cs = new CSInterface();
  const IS_PREMIERE = cs.getHostEnvironment().appName === 'PPRO';

  // ─── ElevenLabs API ───
  const API_BASE = 'https://api.elevenlabs.io/v1';

  // ─── Auto-update (mirrors EasyBlocks Pro pattern) ───
  // latest.json lives in a public GitHub repo, served via jsDelivr CDN for cache-bust.
  // The .zip itself stays on SharePoint (NVIDIA-auth'd). Banner just opens the folder.
  // Multiple manifest URLs — corporate networks (especially Windows) sometimes
  // block raw.githubusercontent.com via SmartScreen / proxy / AV. We try each
  // host in order; first one that returns valid JSON wins. Order matters:
  //   1. raw.githubusercontent.com — canonical, always fresh
  //   2. cdn.jsdelivr.net          — widely allowlisted CDN (may briefly cache)
  //   3. api.github.com/contents   — REST API; always fresh, no CDN cache,
  //                                  returns base64-encoded content (we decode)
  const EL_LATEST_URLS = [
    'https://raw.githubusercontent.com/amitnvda/elevenlabs-releases/main/latest.json',
    'https://cdn.jsdelivr.net/gh/amitnvda/elevenlabs-releases@main/latest.json',
    'https://api.github.com/repos/amitnvda/elevenlabs-releases/contents/latest.json?ref=main'
  ];
  const EL_DOWNLOAD_URL = 'https://nvidia.sharepoint.com/:f:/r/sites/NBU-AcademyDM/R%20%20D/AE%20Plugins%20and%20Scripts/ElevenLabs%20to%20AE?csf=1&web=1&e=AulyVi';
  const EL_DISMISS_KEY  = 'el_update_dismissed';
  const EL_VERSION = (() => {
    // Header badge is the single source of truth for installed version
    const v = document.querySelector('.header-version');
    return v ? v.textContent.replace(/^v/, '').trim() : '0.0.0';
  })();

  // Available models — noSpeed: true means the speed param is not supported
  const MODELS = [
    { id: 'eleven_v3',                label: 'Eleven v3 (latest)',            noSpeed: true },
    { id: 'eleven_multilingual_v2',   label: 'Multilingual v2 (best quality)' },
    { id: 'eleven_turbo_v2_5',        label: 'Turbo v2.5 (low latency)' },
    { id: 'eleven_flash_v2_5',        label: 'Flash v2.5 (fastest)' },
    { id: 'eleven_monolingual_v1',    label: 'Monolingual v1 (English)',      noSpeed: true },
  ];

  // ─── Allowed voices — match by id (preferred) or name ───
  const ALLOWED_VOICES = [
    { name: 'Mark - ConvoAI' },
    { id: '8Ln42OXYupYsag45MAUy', name: 'Jey' },
    { id: 'uTof433lKWylEy1elPTY', name: 'Sienna - Natural and Bright' },
    { name: 'Annie - Bright, Clear, and Engaging' },
    { name: 'Liam - Energetic, Social Media Creator' },
    { id: 'UgBBYS2sOqTuMpoF3BR0', name: 'Mark - Dynamic, Balanced and Emotional' },
  ];

  // ─── State ───
  let apiKey = '';
  let voices = [];
  let isGenerating = false;
  let outputDir = (path && os) ? path.join(os.tmpdir(), 'elevenlabs-ae') : '/tmp/elevenlabs-ae';
  let history = [];
  let pptxSlides = null;          // cached slide list from last PPTX import
  let currentSlideIdx = -1;       // which slide is currently loaded in the script field (-1 = none)
  let slideEdits = new Map();     // Map<slideNum, string> — preserves user edits when navigating
  // Pacing state — keyed by sentence text so user edits don't reset adjacent sentences.
  // Map<sentenceText, 'slow' | 'normal' | 'fast'>
  let pacingMap = new Map();

  // ─── DOM references ───
  const $ = id => document.getElementById(id);

  const el = {
    apiKeyInput:          $('api-key'),
    saveKeyBtn:           $('save-key-btn'),
    voiceSelect:          $('voice-select'),
    modelSelect:          $('model-select'),
    scriptText:           $('script-text'),
    charCount:            $('char-count'),
    addPauses:            $('add-pauses'),
    splitClips:           $('split-clips'),
    addMarkers:           $('add-markers'),
    pausePreview:         $('pause-preview'),
    pausePreviewText:     $('pause-preview-text'),
    pausePreviewCount:    $('pause-preview-count'),
    pausePreviewToggle:   $('pause-preview-toggle'),
    pacingPanel:          $('pacing-panel'),
    pacingList:           $('pacing-list'),
    pacingCount:          $('pacing-count'),
    pacingResetBtn:       $('pacing-reset-btn'),
    pacingToggleBtn:      $('pacing-toggle-btn'),
    stabilitySlider:      $('stability'),
    stabilityVal:         $('stability-val'),
    similaritySlider:     $('similarity'),
    similarityVal:        $('similarity-val'),
    speedSlider:          $('speed'),
    speedVal:             $('speed-val'),
    importPptxBtn:        $('import-pptx-btn'),
    slidePicker:          $('slide-picker'),
    slideList:            $('slide-list'),
    closeSlidePicker:     $('close-slide-picker'),
    reloadPptxBtn:        $('reload-pptx-btn'),
    slideNav:             $('slide-nav'),
    slideNavPrev:         $('slide-nav-prev'),
    slideNavNext:         $('slide-nav-next'),
    slideNavAll:          $('slide-nav-all'),
    slideNavNum:          $('slide-nav-num'),
    slideNavTotal:        $('slide-nav-total'),
    slideNavTitle:        $('slide-nav-title'),
    importProgress:       $('import-progress'),
    importProgressFill:   $('import-progress-fill'),
    filenameInput:        $('filename-input'),
    autoSaveVo:           $('auto-save-vo'),
    saveSpecific:         $('save-specific'),
    specificFolderRow:    $('specific-folder-row'),
    outputPath:           $('output-path'),
    changePathBtn:        $('change-path-btn'),
    openFolderBtn:        $('open-folder-btn'),
    generateBtn:          $('generate-btn'),
    statusBar:            $('status-bar'),
    statusDot:            $('status-dot'),
    statusText:           $('status-text'),
    voiceSearch:          $('voice-search'),
    historyList:          $('history-list'),
    helpBtn:              $('help-btn'),
    helpPanel:            $('help-panel'),
    updateBtn:            $('update-btn'),
    updatePanel:          $('update-panel'),
    updateBanner:         $('updateBanner'),
    updateBannerVersion:  $('updateBannerVersion'),
    updateBannerBtn:      $('updateBannerBtn'),
    updateBannerDismiss:  $('updateBannerDismiss'),
    installZipBtn:        $('install-zip-btn'),
    installDropzone:      $('install-dropzone'),
    installOpenFolderLnk: $('install-open-folder-link'),
    installAutoBtn:       $('install-auto-btn'),
    installSuccess:       $('install-success'),
    installSuccessVersion:$('install-success-version'),
    installSuccessClose:  $('install-success-close'),
    installReloadBtn:     $('install-reload-btn'),
    installCheckBtn:      $('install-check-btn'),
    updateStatusText:     $('update-status-text'),
    historyToggle:        $('history-toggle'),
    historyArrow:         $('history-arrow'),
    historyBody:          $('history-body'),
  };


  // ─── Initialization ───
  function init() {
    loadSavedState();
    populateModels();
    bindEvents();
    bindUpdateBanner();
    ensureOutputDir();
    updateOutputPathDisplay();

    // Rename panel for Premiere Pro
    if (IS_PREMIERE) {
      document.title = '11Labs \u2192 Pr';
      const titleEl = document.querySelector('.header-title');
      if (titleEl) titleEl.textContent = '11Labs \u2192 Pr';
      const versionEl = document.querySelector('.header-version');
      if (versionEl) versionEl.title = 'Running in Adobe Premiere Pro';
    }

    // Manually load the JSX so it works reliably in both AE and Premiere.
    // Manifest-based ScriptPath is unreliable in Premiere Pro.
    loadJSX(() => {
      if (apiKey) {
        setStatus('loading', 'Fetching voices…');
        fetchVoices();
      } else {
        setStatus('idle', 'Enter your ElevenLabs API key to begin.');
      }
    });

    // Auto-update check: boot (after 1.5s) then every 30 min while panel is open
    setTimeout(checkForUpdate, 1500);
    setInterval(checkForUpdate, 30 * 60 * 1000);
  }

  function loadJSX(callback) {
    try {
      const extPath = cs.getSystemPath('EXTENSION');
      const jsxPath = path.join(extPath, 'jsx', 'hostscript.jsx');
      const jsxCode = fs.readFileSync(jsxPath, 'utf8');
      cs.evalScript(jsxCode, result => {
        if (result && result.startsWith('EvalScript')) {
          console.error('JSX eval failed:', result);
        }
        if (callback) callback();
      });
    } catch (e) {
      console.error('loadJSX error:', e.message);
      if (callback) callback();
    }
  }

  function loadSavedState() {
    apiKey = localStorage.getItem('el_api_key') || '';
    outputDir = localStorage.getItem('el_output_dir') || outputDir;
    if (el.apiKeyInput) el.apiKeyInput.value = apiKey;

    const savedStability = localStorage.getItem('el_stability');
    const savedSimilarity = localStorage.getItem('el_similarity');
    const savedSpeed = localStorage.getItem('el_speed');

    if (savedStability) {
      el.stabilitySlider.value = savedStability;
      el.stabilityVal.textContent = savedStability;
    }
    if (savedSimilarity) {
      el.similaritySlider.value = savedSimilarity;
      el.similarityVal.textContent = savedSimilarity;
    }
    if (savedSpeed) {
      el.speedSlider.value = savedSpeed;
      el.speedVal.textContent = savedSpeed;
    }

    const savedAutoSave = localStorage.getItem('el_auto_save_vo');
    const savedSaveSpecific = localStorage.getItem('el_save_specific');
    el.autoSaveVo.checked = savedAutoSave !== null ? savedAutoSave === 'true' : true;
    el.saveSpecific.checked = savedSaveSpecific === 'true';
    updateSpecificFolderVisibility();

    el.addPauses.checked = localStorage.getItem('el_add_pauses') === 'true';
    el.splitClips.checked = localStorage.getItem('el_split_clips') === 'true';
    el.addMarkers.checked = localStorage.getItem('el_add_markers') === 'true';

    const savedModel = localStorage.getItem('el_model');
    if (savedModel) {
      el.modelSelect.dataset.savedModel = savedModel;
    }

    const savedHistory = localStorage.getItem('el_history');
    if (savedHistory) {
      try { history = JSON.parse(savedHistory); } catch (_) {}
      renderHistory();
    }
  }

  function populateModels() {
    el.modelSelect.innerHTML = '';
    MODELS.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m.id;
      opt.textContent = m.label;
      el.modelSelect.appendChild(opt);
    });

    const saved = el.modelSelect.dataset.savedModel;
    if (saved) el.modelSelect.value = saved;
    updateSpeedState();
  }

  function updateSpeedState() {
    const modelId = el.modelSelect.value;
    const model = MODELS.find(m => m.id === modelId);
    const noSpeed = model && model.noSpeed;
    el.speedSlider.disabled = !!noSpeed;
    const hint = noSpeed ? 'Speed not supported by this model' : '';
    el.speedSlider.title = hint;
    el.speedVal.title = hint;
    el.speedVal.style.opacity = noSpeed ? '0.4' : '';
  }

  function bindEvents() {
    // API key
    el.saveKeyBtn.addEventListener('click', onSaveKey);
    el.apiKeyInput.addEventListener('keydown', e => {
      if (e.key === 'Enter') onSaveKey();
    });

    // Text area
    el.scriptText.addEventListener('input', () => {
      updateCharCount();
      updatePausePreview();
      updatePacingPanel();
    });

    // Auto-clean pasted text from Word/PowerPoint/bulleted lists:
    //   • normalize CRLF/CR to LF
    //   • strip zero-width chars (ZWSP / ZWJ / BOM) that survive .trim()
    //   • strip leading list markers from each line (1./1)/•/-/*/–/—)
    //   • drop lines with no letter/digit content (blank, whitespace-only, marker-only)
    //   • collapse to single newlines between non-empty lines
    el.scriptText.addEventListener('paste', (e) => {
      const cd = e.clipboardData || window.clipboardData;
      if (!cd) return;
      const raw = cd.getData('text');
      if (!raw) return;
      const cleaned = raw
        .replace(/\r\n?/g, '\n')
        .replace(/[​‌‍﻿]/g, '')
        .split('\n')
        .map(l => l.trim().replace(LIST_MARKER, '').trim())
        .filter(l => HAS_CONTENT.test(l))
        .join('\n');
      if (cleaned === raw) return; // nothing changed — let native paste handle it
      e.preventDefault();
      const start = el.scriptText.selectionStart;
      const end   = el.scriptText.selectionEnd;
      const cur   = el.scriptText.value;
      el.scriptText.value = cur.slice(0, start) + cleaned + cur.slice(end);
      const caret = start + cleaned.length;
      el.scriptText.selectionStart = el.scriptText.selectionEnd = caret;
      el.scriptText.dispatchEvent(new Event('input', { bubbles: true }));
    });

    // Add pauses toggle
    el.addPauses.addEventListener('change', () => {
      localStorage.setItem('el_add_pauses', String(el.addPauses.checked));
      updatePausePreview();
    });

    // Split clips toggle
    el.splitClips.addEventListener('change', () => {
      localStorage.setItem('el_split_clips', String(el.splitClips.checked));
    });

    // Add markers toggle
    el.addMarkers.addEventListener('change', () => {
      localStorage.setItem('el_add_markers', String(el.addMarkers.checked));
    });

    // Preview collapse / expand
    if (el.pausePreviewToggle) {
      el.pausePreviewToggle.addEventListener('click', () => {
        const collapsed = el.pausePreview.classList.toggle('collapsed');
        el.pausePreviewToggle.textContent = collapsed ? 'Show' : 'Hide';
      });
    }

    // Pacing panel — collapse / reset
    if (el.pacingToggleBtn) {
      el.pacingToggleBtn.addEventListener('click', () => {
        const collapsed = el.pacingPanel.classList.toggle('collapsed');
        el.pacingToggleBtn.textContent = collapsed ? 'Show' : 'Hide';
      });
    }
    if (el.pacingResetBtn) {
      el.pacingResetBtn.addEventListener('click', () => {
        pacingMap.clear();
        updatePacingPanel();
      });
    }

    // Sliders
    el.stabilitySlider.addEventListener('input', () => {
      el.stabilityVal.textContent = el.stabilitySlider.value;
      localStorage.setItem('el_stability', el.stabilitySlider.value);
    });
    el.similaritySlider.addEventListener('input', () => {
      el.similarityVal.textContent = el.similaritySlider.value;
      localStorage.setItem('el_similarity', el.similaritySlider.value);
    });
    el.speedSlider.addEventListener('input', () => {
      el.speedVal.textContent = el.speedSlider.value;
      localStorage.setItem('el_speed', el.speedSlider.value);
    });

    // Model select
    el.modelSelect.addEventListener('change', () => {
      localStorage.setItem('el_model', el.modelSelect.value);
      updateSpeedState();
      updatePausePreview();
      updatePacingPanel();
    });

    // Output folder checkboxes (mutually exclusive)
    el.autoSaveVo.addEventListener('change', () => {
      if (el.autoSaveVo.checked) {
        el.saveSpecific.checked = false;
        localStorage.setItem('el_save_specific', 'false');
      }
      localStorage.setItem('el_auto_save_vo', String(el.autoSaveVo.checked));
      updateSpecificFolderVisibility();
    });
    el.saveSpecific.addEventListener('change', () => {
      if (el.saveSpecific.checked) {
        el.autoSaveVo.checked = false;
        localStorage.setItem('el_auto_save_vo', 'false');
      }
      localStorage.setItem('el_save_specific', String(el.saveSpecific.checked));
      updateSpecificFolderVisibility();
    });

    // Output path
    el.changePathBtn.addEventListener('click', changeOutputDir);

    // Open saved folder
    el.openFolderBtn.addEventListener('click', async () => {
      try {
        const dir = await resolveOutputDir();
        openInFinder(dir);
      } catch (e) {
        setStatus('error', e.message);
      }
    });

    // PPTX import
    el.importPptxBtn.addEventListener('click', onImportPPTX);
    el.closeSlidePicker.addEventListener('click', () => {
      el.slidePicker.style.display = 'none';
    });
    el.reloadPptxBtn.addEventListener('click', () => {
      el.slidePicker.style.display = 'none';
      pptxSlides = null;
      currentSlideIdx = -1;
      slideEdits.clear();
      updateSlideNav();
      onImportPPTX();
    });

    // Slide navigator (visible after PPTX import — walks the deck without re-opening the picker)
    if (el.slideNavPrev) {
      el.slideNavPrev.addEventListener('click', () => {
        if (!pptxSlides || currentSlideIdx <= 0) return;
        loadSlide(currentSlideIdx - 1);
      });
    }
    if (el.slideNavNext) {
      el.slideNavNext.addEventListener('click', () => {
        if (!pptxSlides || currentSlideIdx < 0 || currentSlideIdx >= pptxSlides.length - 1) return;
        loadSlide(currentSlideIdx + 1);
      });
    }
    if (el.slideNavAll) {
      el.slideNavAll.addEventListener('click', () => {
        if (!pptxSlides) return;
        captureCurrentEdit(); // preserve edits before switching views
        el.slidePicker.style.display = 'flex';
      });
    }

    // Generate
    el.generateBtn.addEventListener('click', onGenerate);


    // Help panel toggle
    if (el.helpBtn) {
      el.helpBtn.addEventListener('click', () => {
        const open = el.helpPanel.classList.contains('visible');
        if (el.updatePanel) el.updatePanel.classList.remove('visible');
        if (el.updateBtn) el.updateBtn.classList.remove('active');
        el.helpPanel.classList.toggle('visible', !open);
        el.helpBtn.classList.toggle('active', !open);
      });
    }

    // Install panel toggle — also kicks off a manual update check on open so
    // the user immediately sees status (up-to-date / available / network error)
    // without having to hunt for the small "Check for updates" link.
    if (el.updateBtn) {
      el.updateBtn.addEventListener('click', () => {
        const open = el.updatePanel.classList.contains('visible');
        el.helpPanel.classList.remove('visible');
        el.helpBtn.classList.remove('active');
        el.updatePanel.classList.toggle('visible', !open);
        el.updateBtn.classList.toggle('active', !open);
        if (!open && !(el.installSuccess && el.installSuccess.style.display === 'flex')) {
          // Just opened (and we're not in the post-install success state).
          // Show an immediate "Checking…" state so the button can't be clicked
          // in its stale default before the network fetch resolves.
          setUpdateStatus('Checking for updates…');
          _setAutoBtnState('checking');
          checkForUpdate({ manual: true });
        }
      });
    }

    if (el.installZipBtn) el.installZipBtn.addEventListener('click', browseAndInstallZip);

    // SharePoint link inside install panel
    if (el.installOpenFolderLnk) {
      el.installOpenFolderLnk.addEventListener('click', e => {
        e.preventDefault();
        try {
          if (typeof cep !== 'undefined' && cep.util && cep.util.openURLInDefaultBrowser) {
            cep.util.openURLInDefaultBrowser(EL_DOWNLOAD_URL);
          } else if (childProcess) {
            childProcess.exec(`open "${EL_DOWNLOAD_URL}"`);
          }
        } catch (e) { /* swallow */ }
      });
    }

    // Drag-and-drop install
    if (el.installDropzone) {
      const dz = el.installDropzone;
      dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('drag-over'); });
      dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));
      dz.addEventListener('drop', e => {
        e.preventDefault();
        dz.classList.remove('drag-over');
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f && f.path && f.name.toLowerCase().endsWith('.zip')) {
          installFromZip(f.path);
        } else {
          setUpdateStatus('Please drop a .zip file');
        }
      });
    }

    // History toggle
    if (el.historyToggle) {
      el.historyToggle.addEventListener('click', () => {
        const isOpen = el.historyBody.style.maxHeight !== '0px';
        if (isOpen) {
          el.historyBody.style.maxHeight = '0px';
          el.historyArrow.style.transform = 'rotate(-90deg)';
        } else {
          el.historyBody.style.maxHeight = el.historyBody.scrollHeight + 'px';
          el.historyArrow.style.transform = '';
        }
      });
    }
  }

  // ─── API key ───
  function onSaveKey() {
    const key = el.apiKeyInput.value.trim();
    if (!key) {
      setStatus('error', 'Please enter a valid API key.');
      return;
    }
    apiKey = key;
    localStorage.setItem('el_api_key', apiKey);
    setStatus('loading', 'Fetching voices…');
    fetchVoices();
  }

  // ─── Fetch voices ───
  async function fetchVoices() {
    try {
      const res = await fetch(`${API_BASE}/voices`, {
        headers: { 'xi-api-key': apiKey }
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.detail?.message || `HTTP ${res.status}`);
      }

      const data = await res.json();
      voices = data.voices || [];

      populateVoiceDropdown();
      setStatus('success', `${voices.length} voices loaded. Ready to generate.`);

    } catch (e) {
      setStatus('error', `Failed to load voices: ${e.message}`);
      el.voiceSelect.innerHTML = '<option value="">— Load failed —</option>';
      el.voiceSelect.disabled = true;
    }
  }

  function populateVoiceDropdown(filter) {
    const savedVoice = localStorage.getItem('el_voice_id');
    const currentVoice = el.voiceSelect.value || savedVoice;

    el.voiceSelect.innerHTML = '';
    el.voiceSelect.disabled = false;

    const allowed = voices.filter(v =>
      ALLOWED_VOICES.some(a =>
        (a.id && a.id === v.voice_id) ||
        a.name.toLowerCase().trim() === v.name.toLowerCase().trim()
      )
    );
    const query = (filter || '').toLowerCase();
    const filtered = query
      ? allowed.filter(v => v.name.toLowerCase().includes(query))
      : allowed;

    filtered.forEach(v => {
      const opt = document.createElement('option');
      opt.value = v.voice_id;
      opt.textContent = `${v.name}${v.labels?.accent ? ` (${v.labels.accent})` : ''}`;
      el.voiceSelect.appendChild(opt);
    });

    if (currentVoice && filtered.some(v => v.voice_id === currentVoice)) {
      el.voiceSelect.value = currentVoice;
    }

    // Show search input once voices are available
    if (el.voiceSearch) {
      el.voiceSearch.style.display = '';
      if (!el.voiceSearch._bound) {
        el.voiceSearch._bound = true;
        el.voiceSearch.addEventListener('input', () => {
          populateVoiceDropdown(el.voiceSearch.value);
        });
      }
    }

    el.voiceSelect.addEventListener('change', () => {
      localStorage.setItem('el_voice_id', el.voiceSelect.value);
    });
  }

  // ─── Generate ───
  async function onGenerate() {
    if (isGenerating) return;

    const text = el.scriptText.value.trim();
    if (!text) {
      setStatus('error', 'Please enter some text to synthesize.');
      return;
    }

    const voiceId = el.voiceSelect.value;
    if (!voiceId) {
      setStatus('error', 'Please select a voice.');
      return;
    }

    if (!apiKey) {
      setStatus('error', 'Please save your API key first.');
      return;
    }

    isGenerating = true;
    el.generateBtn.disabled = true;

    // 1. Apply per-sentence pacing tags first (v3 only) — done BEFORE pauses
    //    so the sentence-boundary regex sees clean text.
    let ttsText = applyPacing(text);
    const pacingAdjusted = pacingMap.size;

    // 2. Optional: insert pause markers between sentences.
    //    v3 uses [pause] audio tag; older models use " -- ".
    //    Uses splitSentences (which handles list markers, newlines, no-space paste)
    //    then joins with the marker between them. Idempotent — if a sentence already
    //    ends with the marker text, joining adds a single one anyway and ElevenLabs
    //    de-dups consecutive identical markers.
    let pauseCount = 0;
    if (el.addPauses.checked) {
      const isV3 = el.modelSelect.value === 'eleven_v3';
      const marker = isV3 ? '[pause]' : '--';
      const sentences = splitSentences(ttsText);
      if (sentences.length > 1) {
        ttsText = sentences.join(` ${marker} `);
        pauseCount = sentences.length - 1;
      }
    }

    const fragments = [];
    if (pauseCount > 0) fragments.push(`${pauseCount} pause${pauseCount === 1 ? '' : 's'}`);
    if (pacingAdjusted > 0) fragments.push(`${pacingAdjusted} paced`);
    if (el.splitClips.checked) fragments.push('split');
    setStatus('loading', fragments.length
      ? `Generating audio (${fragments.join(', ')})…`
      : 'Generating audio…');

    console.log('[ElevenLabs] Sending text:', JSON.stringify(ttsText));
    if (pauseCount > 0)     console.log(`[ElevenLabs] Inserted ${pauseCount} pause(s).`);
    if (pacingAdjusted > 0) console.log(`[ElevenLabs] Applied pacing to ${pacingAdjusted} sentence(s).`);

    try {
      let audioBuffer, cutTimes = null;

      if (el.splitClips.checked) {
        const result = await callTTSWithTimestamps(ttsText, voiceId);
        audioBuffer = result.audio;
        // cutTimes = intermediate boundaries only. N cuts → N+1 clips (last extends to source duration).
        cutTimes = result.alignment ? findSentenceCutTimes(result.alignment) : null;
        if (cutTimes && cutTimes.length >= 1) {
          // Refine each cut to the quietest point in the audio (silence-snap).
          // Alignment timestamps can land mid-syllable; snapping to actual audio
          // silence makes the cut land perfectly in the gap between sentences.
          try {
            const refined = await snapCutsToSilence(audioBuffer, cutTimes);
            if (refined && refined.length === cutTimes.length) {
              console.log('[ElevenLabs] Cuts snapped to silence:', cutTimes, '→', refined);
              cutTimes = refined;
            }
          } catch (snapErr) {
            console.warn('[ElevenLabs] Silence-snap failed, using alignment cuts:', snapErr.message);
          }
          console.log(`[ElevenLabs] Will split into ${cutTimes.length + 1} clips at:`, cutTimes);
        } else {
          console.warn('[ElevenLabs] No sentence boundaries found — placing as a single clip.');
          cutTimes = null;
        }
      } else {
        audioBuffer = await callTTS(ttsText, voiceId);
      }

      // Marker labels — computed once, used by both paths below.
      let markerLabels = null;
      if (el.addMarkers.checked) {
        if (el.splitClips.checked && cutTimes && cutTimes.length >= 1) {
          const sentences = splitSentences(text);
          markerLabels = sentences.map(s => firstWords(s, 8));
          const clipCount = cutTimes.length + 1;
          while (markerLabels.length < clipCount) markerLabels.push('');
          markerLabels = markerLabels.slice(0, clipCount);
        } else {
          markerLabels = [firstWords(text, 8)];
        }
      }

      if (el.splitClips.checked && cutTimes && cutTimes.length >= 1) {
        // ── Split path ──────────────────────────────────────────────────────
        // Slice the audio buffer into individual WAV files (one per sentence
        // + 0.4 s tail). Each file is self-contained so AE/Premiere never
        // have to share a project item between clips — this eliminates the
        // setInPoint/setOutPoint contamination that caused overlaps.
        setStatus('loading', 'Splitting audio into clips…');
        const clipFiles = await splitAudioIntoFiles(audioBuffer, cutTimes, voiceId);
        await importMultipleIntoAE(clipFiles, voiceId, text, markerLabels);
      } else {
        // ── Single-clip path ────────────────────────────────────────────────
        // Append 0.5 s of silence so ElevenLabs doesn't clip the tail.
        let audioExt = '.mp3';
        try {
          const wavBuffer = await appendSilenceTail(audioBuffer);
          if (wavBuffer) { audioBuffer = wavBuffer; audioExt = '.wav'; }
        } catch (tailErr) {
          console.warn('[ElevenLabs] appendSilenceTail failed, saving original MP3:', tailErr.message);
        }
        const filePath = await saveAudioFile(audioBuffer, voiceId, audioExt);
        await importIntoAE(filePath, voiceId, text, null, markerLabels);
      }

    } catch (e) {
      setStatus('error', e.message);
    } finally {
      isGenerating = false;
      el.generateBtn.disabled = false;
    }
  }

  async function callTTS(text, voiceId) {
    const stability = parseFloat(el.stabilitySlider.value);
    const similarity = parseFloat(el.similaritySlider.value);
    const modelId = el.modelSelect.value;
    const model = MODELS.find(m => m.id === modelId);
    const speed = (!model || !model.noSpeed) ? parseFloat(el.speedSlider.value) : undefined;

    setStatus('loading', 'Calling ElevenLabs API…');

    const res = await fetch(`${API_BASE}/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
        'Accept': 'audio/mpeg',
      },
      body: JSON.stringify({
        text,
        model_id: modelId,
        voice_settings: {
          stability,
          similarity_boost: similarity,
          speed,
        },
      }),
    });

    if (!res.ok) {
      const errBody = await res.json().catch(() => ({}));
      const msg = errBody.detail?.message || errBody.detail || `HTTP ${res.status}`;
      throw new Error(`ElevenLabs error: ${msg}`);
    }

    const arrayBuf = await res.arrayBuffer();
    return Buffer.from(arrayBuf);
  }

  // ─── TTS with character-level timing (for auto-split) ───
  async function callTTSWithTimestamps(text, voiceId) {
    const stability = parseFloat(el.stabilitySlider.value);
    const similarity = parseFloat(el.similaritySlider.value);
    const modelId = el.modelSelect.value;
    const model = MODELS.find(m => m.id === modelId);
    const speed = (!model || !model.noSpeed) ? parseFloat(el.speedSlider.value) : undefined;

    setStatus('loading', 'Calling ElevenLabs API (with timestamps)…');

    const res = await fetch(`${API_BASE}/text-to-speech/${voiceId}/with-timestamps`, {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        text,
        model_id: modelId,
        voice_settings: { stability, similarity_boost: similarity, speed },
      }),
    });

    if (!res.ok) {
      const errBody = await res.json().catch(() => ({}));
      const msg = errBody.detail?.message || errBody.detail || `HTTP ${res.status}`;
      throw new Error(`ElevenLabs error: ${msg}`);
    }

    const data = await res.json();
    const audio = Buffer.from(data.audio_base64, 'base64');
    return { audio, alignment: data.alignment || data.normalized_alignment || null };
  }

  // ─── Find sentence cut-times from alignment ───
  // Returns array of INTERMEDIATE cut seconds — the boundaries BETWEEN sentences only.
  // N intermediate cuts → N+1 clips. The last clip extends to the audio's source duration
  // on the host side (so any tail silence/decay is preserved instead of clipped at the
  // last character's end-time, which would sound abrupt).
  function findSentenceCutTimes(alignment) {
    if (!alignment || !alignment.characters || !alignment.character_end_times_seconds) return null;
    const chars = alignment.characters;
    const ends = alignment.character_end_times_seconds;
    const starts = alignment.character_start_times_seconds || ends;
    const ABBREV = new Set(['Mr','Mrs','Ms','Dr','Sr','Jr','Prof','St','vs','etc']);

    const cuts = [];
    for (let i = 0; i < chars.length - 1; i++) {
      const ch = chars[i];
      if (ch !== '.' && ch !== '!' && ch !== '?') continue;

      // Walk forward over whitespace and any inline directives like [pause] / [slowly]
      let j = i + 1;
      while (j < chars.length && /\s/.test(chars[j])) j++;
      while (j < chars.length && chars[j] === '[') {
        while (j < chars.length && chars[j] !== ']') j++;
        j++; // past ]
        while (j < chars.length && /\s/.test(chars[j])) j++;
      }
      if (j >= chars.length) break;

      // Sentence start should be uppercase / digit / opening quote
      const next = chars[j];
      if (!/[A-Z0-9"'(\[]/.test(next)) continue;

      // Skip abbreviations (the word ending at i)
      let s = i - 1;
      while (s >= 0 && /\w/.test(chars[s])) s--;
      const word = chars.slice(s + 1, i).join('');
      if (ABBREV.has(word)) continue;

      // Cut at the QUIETEST point: midpoint between the period's end and the
      // next sentence's first character start. This puts the cut deep inside
      // the silence/breath gap so neither clip slices into audible speech.
      // Falls back to whichever boundary is defined if one is missing.
      const tailEnd  = (typeof ends[i]   === 'number') ? ends[i]   : starts[j];
      const headStart = (typeof starts[j] === 'number') ? starts[j] : ends[i];
      const cutAt = (tailEnd + headStart) / 2;
      cuts.push(cutAt);
    }

    // Intentionally do NOT push a final boundary here. The host script extends
    // the last clip to the audio file's source duration so tail silence/decay
    // isn't clipped off (which would sound abrupt).
    return cuts;
  }

  // ─── Snap each cut to the MIDDLE of the longest silence near the suggested time ──
  // Alignment timestamps from ElevenLabs are character-level and can land mid-syllable.
  // Decode the MP3, scan a SYMMETRIC window around each suggested cut, find the
  // longest sustained silent region (not just the lowest single instant), and place
  // the cut in the MIDDLE of that region. This makes the previous clip end with a
  // natural trail and the next clip start with a natural lead-in — no chopped speech,
  // no big empty intro.
  // Returns an array of refined cut seconds (same length as input), or the originals
  // for any cut where no silent region was found.
  async function snapCutsToSilence(mp3Buffer, suggestedCutsSeconds) {
    if (!mp3Buffer || !suggestedCutsSeconds || suggestedCutsSeconds.length === 0) {
      return suggestedCutsSeconds || null;
    }
    // Node Buffer → ArrayBuffer for Web Audio decoder
    const ab = mp3Buffer.buffer.slice(
      mp3Buffer.byteOffset,
      mp3Buffer.byteOffset + mp3Buffer.byteLength
    );
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    const ctx = new AC();
    try {
      const decoded = await ctx.decodeAudioData(ab);
      const samples = decoded.getChannelData(0);
      const sr      = decoded.sampleRate;
      const total   = samples.length;

      // Symmetric search window — alignment may be off in either direction.
      // 500 ms each side gives room to find true silence without crossing into
      // adjacent sentences' content.
      const SEARCH_SEC = 0.50;
      const RMS_WIN    = Math.max(1, Math.floor(0.030 * sr)); // 30 ms RMS window — robust to brief mid-speech dips
      const STEP       = Math.max(1, Math.floor(0.010 * sr)); // 10 ms hop
      const SILENT_RMS = 0.012;                                // RMS below this counts as silence
      const MIN_SILENT_SEC = 0.060;                            // ignore tiny dips < 60 ms

      const refined = suggestedCutsSeconds.map(t => {
        const center = Math.floor(t * sr);
        const lo = Math.max(0, center - Math.floor(SEARCH_SEC * sr));
        const hi = Math.min(total - RMS_WIN, center + Math.floor(SEARCH_SEC * sr));

        // Walk the window, accumulating contiguous silent runs.
        // Track the longest run — that's where the real sentence gap lives.
        let bestStart = -1, bestEnd = -1;
        let curStart = -1;
        for (let i = lo; i <= hi; i += STEP) {
          let sumSq = 0;
          for (let k = 0; k < RMS_WIN; k++) {
            const s = samples[i + k];
            sumSq += s * s;
          }
          const rms = Math.sqrt(sumSq / RMS_WIN);
          if (rms < SILENT_RMS) {
            if (curStart < 0) curStart = i;
          } else if (curStart >= 0) {
            if ((i - curStart) > (bestEnd - bestStart)) {
              bestStart = curStart;
              bestEnd = i;
            }
            curStart = -1;
          }
        }
        // Close out a silent run that extended to the end of the window.
        if (curStart >= 0 && (hi - curStart) > (bestEnd - bestStart)) {
          bestStart = curStart;
          bestEnd = hi;
        }

        const runLen = (bestEnd - bestStart) / sr;
        if (bestStart >= 0 && runLen >= MIN_SILENT_SEC) {
          // Cut in the middle of the silent run.
          return ((bestStart + bestEnd) / 2) / sr;
        }
        // No real silence in window — keep the alignment-derived cut.
        return t;
      });

      // Guarantee strict monotonicity so the host script doesn't produce zero-length clips
      for (let i = 1; i < refined.length; i++) {
        if (refined[i] <= refined[i - 1]) refined[i] = refined[i - 1] + 0.001;
      }
      return refined;
    } finally {
      try { ctx.close(); } catch (_) {}
    }
  }

  // ─── Split audio buffer into individual WAV files (one per sentence) ────
  // Each clip is sliced from the source PCM and gets CLIP_TAIL_SECS of
  // silence appended so the voice decay isn't cut off at the sentence boundary.
  // Using individual files (rather than one shared project item with setInPoint/
  // setOutPoint) avoids Premiere modifying all already-placed instances when the
  // master clip's trim points change, which caused the overlap bug.
  const CLIP_TAIL_SECS = 0.4;

  async function splitAudioIntoFiles(mp3Buffer, cutTimes, voiceId) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) throw new Error('Web Audio API not available');
    const ctx = new AC();
    try {
      const ab = mp3Buffer.buffer.slice(mp3Buffer.byteOffset, mp3Buffer.byteOffset + mp3Buffer.byteLength);
      const decoded = await ctx.decodeAudioData(ab);
      const sr     = decoded.sampleRate;
      const numCh  = decoded.numberOfChannels;

      const dir       = await resolveOutputDir();
      const ts        = Date.now();
      const voiceName = (voices.find(v => v.voice_id === voiceId)?.name || 'voice')
        .replace(/[^a-zA-Z0-9_-]/g, '_');

      const boundaries = [...cutTimes, decoded.duration];
      const files = [];
      let prevCut = 0;

      for (let i = 0; i < boundaries.length; i++) {
        const thisCut = boundaries[i];
        if (thisCut <= prevCut) continue;

        const isLast  = i === boundaries.length - 1;
        const clipEnd = isLast
          ? decoded.duration
          : Math.min(thisCut + CLIP_TAIL_SECS, decoded.duration);

        const startSample = Math.floor(prevCut * sr);
        const endSample   = Math.min(Math.ceil(clipEnd * sr), decoded.length);
        if (endSample <= startSample) { prevCut = thisCut; continue; }

        const clipBuf = ctx.createBuffer(numCh, endSample - startSample, sr);
        for (let ch = 0; ch < numCh; ch++) {
          clipBuf.getChannelData(ch).set(
            decoded.getChannelData(ch).subarray(startSample, endSample)
          );
        }

        const wavBuf  = encodeWAV(clipBuf);
        const idx     = String(i + 1).padStart(2, '0');
        const filePath = path.join(dir, `EL_${voiceName}_${ts}_${idx}.wav`);

        await new Promise((res, rej) =>
          fs.writeFile(filePath, wavBuf, e => e ? rej(e) : res())
        );
        files.push(filePath);
        prevCut = thisCut;
      }

      if (!files.length) throw new Error('No clip files were created');
      return files;
    } finally {
      try { ctx.close(); } catch (_) {}
    }
  }

  async function importMultipleIntoAE(files, voiceId, text, markerLabels) {
    setStatus('loading', 'Importing clips into timeline…');

    const escapedFiles = files.map(f => f.replace(/\\/g, '\\\\').replace(/"/g, '\\"'));
    const filesCsv  = escapedFiles.join('|');
    const labelsCsv = (markerLabels || [])
      .map(l => String(l || '').replace(/[|"\\]/g, '')).join('|');

    const script = `importAndPlaceAudioMultiple("${filesCsv}", "${labelsCsv}")`;

    return new Promise((resolve, reject) => {
      cs.evalScript(script, result => {
        if (!result || result.startsWith('ERROR:') || result.startsWith('EvalScript')) {
          reject(new Error(result ? result.replace('ERROR:', '').trim() : 'Unknown error'));
          return;
        }
        addToHistory(voiceId, text, files[0], `${files.length} clips`);
        setStatus('success', `Placed ${files.length} clip${files.length > 1 ? 's' : ''} on timeline.`);
        resolve();
      });
    });
  }

  // ─── Append PCM silence to an MP3 buffer, return a WAV Buffer ───────────
  // ElevenLabs often clips the very end of the generated audio. We decode the
  // MP3 with Web Audio, append TAIL_SECS of zeros, and re-encode as 16-bit WAV.
  // WAV encoding needs no external library and is natively supported by AE/Premiere.
  const AUDIO_TAIL_SECS = 0.5;

  function encodeWAV(audioBuffer) {
    const numCh  = audioBuffer.numberOfChannels;
    const sr     = audioBuffer.sampleRate;
    const len    = audioBuffer.length;
    const bps    = 2; // 16-bit = 2 bytes per sample
    const data   = len * numCh * bps;
    const buf    = new ArrayBuffer(44 + data);
    const v      = new DataView(buf);
    const str    = (off, s) => { for (let i = 0; i < s.length; i++) v.setUint8(off + i, s.charCodeAt(i)); };
    str(0,  'RIFF'); v.setUint32(4,  36 + data,        true);
    str(8,  'WAVE'); str(12, 'fmt ');
    v.setUint32(16, 16,             true);  // subchunk size
    v.setUint16(20, 1,              true);  // PCM
    v.setUint16(22, numCh,          true);
    v.setUint32(24, sr,             true);
    v.setUint32(28, sr * numCh * bps, true);
    v.setUint16(32, numCh * bps,    true);
    v.setUint16(34, 16,             true);  // bits per sample
    str(36, 'data'); v.setUint32(40, data, true);
    let off = 44;
    for (let i = 0; i < len; i++) {
      for (let ch = 0; ch < numCh; ch++) {
        const s = Math.max(-1, Math.min(1, audioBuffer.getChannelData(ch)[i]));
        v.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
        off += 2;
      }
    }
    return Buffer.from(buf);
  }

  async function appendSilenceTail(mp3Buffer) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    const ctx = new AC();
    try {
      const ab = mp3Buffer.buffer.slice(
        mp3Buffer.byteOffset,
        mp3Buffer.byteOffset + mp3Buffer.byteLength
      );
      const decoded  = await ctx.decodeAudioData(ab);
      const sr       = decoded.sampleRate;
      const numCh    = decoded.numberOfChannels;
      const tailLen  = Math.floor(AUDIO_TAIL_SECS * sr);
      const newBuf   = ctx.createBuffer(numCh, decoded.length + tailLen, sr);
      for (let ch = 0; ch < numCh; ch++) {
        newBuf.getChannelData(ch).set(decoded.getChannelData(ch));
        // remaining samples are already zero (silence)
      }
      return encodeWAV(newBuf);
    } finally {
      try { ctx.close(); } catch (_) {}
    }
  }

  async function saveAudioFile(buffer, voiceId, ext) {
    setStatus('loading', 'Saving audio file…');

    const dir = await resolveOutputDir();
    const timestamp = Date.now();
    const voiceName = (voices.find(v => v.voice_id === voiceId)?.name || 'voice')
      .replace(/[^a-zA-Z0-9_-]/g, '_');

    const fileExt = ext || '.mp3';
    const customName = el.filenameInput ? el.filenameInput.value.trim() : '';
    let fileName;
    if (customName) {
      fileName = customName.replace(/[/\\:*?"<>|]/g, '_');
      // Replace or append the correct extension
      fileName = fileName.replace(/\.(mp3|wav)$/i, '') + fileExt;
    } else {
      fileName = `EL_${voiceName}_${timestamp}${fileExt}`;
    }

    const filePath = path.join(dir, fileName);

    return new Promise((resolve, reject) => {
      fs.writeFile(filePath, buffer, err => {
        if (err) reject(new Error(`Failed to save audio: ${err.message}`));
        else resolve(filePath);
      });
    });
  }

  async function importIntoAE(filePath, voiceId, text, cutTimes, markerLabels) {
    setStatus('loading', 'Importing into timeline…');

    // Escape backslashes for ExtendScript string safety
    const escapedPath = filePath.replace(/\\/g, '\\\\').replace(/"/g, '\\"');

    // Encode marker labels as a pipe-delimited string (pipes and quotes stripped from labels).
    // Empty string = no markers.
    const encodeLabels = labels =>
      labels ? labels.map(l => String(l).replace(/[|"\\]/g, '')).join('|') : '';

    // cutTimes (when present) holds INTERMEDIATE cuts only — N cuts → N+1 clips.
    // Use the split function if we have at least one intermediate cut; otherwise single insert.
    let script;
    if (cutTimes && cutTimes.length >= 1) {
      const labelsArg = encodeLabels(markerLabels);
      script = `importAndPlaceAudioSplit("${escapedPath}", "${cutTimes.join(',')}", "${labelsArg}")`;
    } else {
      const labelArg = markerLabels && markerLabels[0]
        ? String(markerLabels[0]).replace(/[|"\\]/g, '')
        : '';
      script = labelArg
        ? `importAndPlaceAudio("${escapedPath}", "${labelArg}")`
        : `importAndPlaceAudio("${escapedPath}")`;
    }

    return new Promise((resolve, reject) => {
      cs.evalScript(script, result => {
        if (!result || result.startsWith('ERROR:') || result.startsWith('EvalScript')) {
          reject(new Error(result ? result.replace('ERROR:', '').trim() : 'Unknown error'));
          return;
        }
        const layerName = result.replace('OK:', '');
        addToHistory(voiceId, text, filePath, layerName);
        const clipCount = cutTimes && cutTimes.length >= 1 ? cutTimes.length + 1 : 0;
        const splitNote = clipCount > 1 ? ` (${clipCount} clips)` : '';
        setStatus('success', `Placed "${layerName}"${splitNote} on timeline.`);
        resolve();
      });
    });
  }


  // ─── PPTX import ───
  // Uses AE's native File.openDialog() via ExtendScript — works in all AE versions.
  function onImportPPTX() {
    // If slides are already loaded, just reopen the picker
    if (pptxSlides) {
      el.slidePicker.style.display = 'flex';
      return;
    }

    setStatus('loading', 'Opening file picker…');
    cs.evalScript('selectPPTXFile()', result => {
      if (!result || result === 'CANCELLED' || result.trim() === '') {
        setStatus('idle', 'No file selected.');
        return;
      }
      if (result.startsWith('ERROR:')) {
        setStatus('error', 'File picker error: ' + result.replace('ERROR:', '').trim());
        return;
      }
      const pptxPath = result.replace('OK:', '').trim();
      if (!pptxPath.toLowerCase().endsWith('.pptx')) {
        setStatus('error', 'Please select a .pptx file.');
        return;
      }
      setStatus('loading', 'Reading PPTX…');
      parsePPTX(pptxPath);
    });
  }

  // Shell-safe single-quote wrapper (used by Mac/Linux branches of install flows below)
  const sq = p => "'" + p.replace(/'/g, "'\\''") + "'";

  async function parsePPTX(pptxPath) {
    // Extract PPTX contents (it's a ZIP) to a temp dir using a system tool that
    // ships with the OS — no JS ZIP parser dependency, reliable across all PPTX variants.
    //   • macOS / Linux → `unzip` (always present; supports glob filtering)
    //   • Windows 10 build 17063+ / 11 → `tar.exe` in System32 (extracts ZIPs natively)
    // Use execFileSync with an arg array to sidestep all shell-quoting differences.
    const tmpDir = path.join(os.tmpdir(), 'el_pptx_' + Date.now());
    const isWin = process.platform === 'win32';

    try {
      fs.mkdirSync(tmpDir, { recursive: true });

      // Extract slides, rels, and notes.
      // unzip exits 11 when a glob matches nothing — acceptable.
      // ENOENT means the tool itself is missing — surface that as a real error.
      try {
        if (isWin) {
          // PowerShell Expand-Archive is more reliable than tar.exe on Windows —
          // tar can silently fail on network paths, UNC paths, or files with spaces,
          // causing "No slides found" even when the PPTX is valid.
          // -LiteralPath avoids wildcard interpretation in the file path.
          const escapedSrc = pptxPath.replace(/'/g, "''");
          const escapedDst = tmpDir.replace(/'/g, "''");
          childProcess.execSync(
            `powershell -NoProfile -Command "Expand-Archive -LiteralPath '${escapedSrc}' -DestinationPath '${escapedDst}' -Force"`,
            { timeout: 30000, stdio: 'pipe' }
          );
        } else {
          childProcess.execFileSync('unzip', [
            '-q', pptxPath,
            'ppt/slides/*.xml',
            'ppt/slides/_rels/*.rels',
            'ppt/notesSlides/*.xml',
            '-d', tmpDir
          ], { timeout: 15000, stdio: 'pipe' });
        }
      } catch (extractErr) {
        if (!isWin && extractErr && extractErr.code === 'ENOENT') {
          throw new Error('unzip command not found.');
        }
        // Surface the actual extraction error instead of silently swallowing it,
        // so users see a meaningful message rather than "No slides found".
        if (extractErr && extractErr.message) {
          throw new Error('Failed to extract PPTX: ' + extractErr.message.split('\n')[0]);
        }
      }

      const slidesDir = path.join(tmpDir, 'ppt', 'slides');
      if (!fs.existsSync(slidesDir)) {
        setStatus('error', 'No slides found in this PPTX file.');
        return;
      }

      const slideNums = fs.readdirSync(slidesDir)
        .filter(f => /^slide\d+\.xml$/.test(f))
        .map(f => parseInt(f.match(/\d+/)[0]))
        .sort((a, b) => a - b);

      if (slideNums.length === 0) {
        setStatus('error', 'No slides found in this PPTX file.');
        return;
      }

      showImportProgress(0);
      const slides = [];

      for (let i = 0; i < slideNums.length; i++) {
        const n = slideNums[i];
        setStatus('loading', `Reading slide ${i + 1} / ${slideNums.length}…`);
        showImportProgress(Math.round((i / slideNums.length) * 100));
        await new Promise(r => setTimeout(r, 0));

        // Slide title
        let title = '';
        try {
          const xml = fs.readFileSync(path.join(slidesDir, `slide${n}.xml`), 'utf8');
          title = extractSlideTitle(xml);
        } catch (_) {}

        // Notes — use .rels file to find the correct notesSlide file number
        let notes = '';
        try {
          let notesFile = `notesSlide${n}.xml`;
          const relsPath = path.join(slidesDir, '_rels', `slide${n}.xml.rels`);
          if (fs.existsSync(relsPath)) {
            const relsXml = fs.readFileSync(relsPath, 'utf8');
            const m = relsXml.match(/Target="\.\.\/notesSlides\/(notesSlide\d+\.xml)"/);
            if (m) notesFile = m[1];
          }
          const notesFilePath = path.join(tmpDir, 'ppt', 'notesSlides', notesFile);
          if (fs.existsSync(notesFilePath)) {
            const notesXml = fs.readFileSync(notesFilePath, 'utf8');
            notes = extractSlideNotes(notesXml);
          }
        } catch (_) {}

        slides.push({ num: n, title, notes });
      }

      showImportProgress(100);
      setTimeout(() => hideImportProgress(), 600);

      pptxSlides = slides;
      currentSlideIdx = -1;          // fresh deck → no slide loaded yet
      slideEdits.clear();             // discard any prior deck's edits
      updateSlideNav();               // hide navigator until a slide is picked
      renderSlidePicker(slides);
      setStatus('idle', `${slides.length} slides loaded — click one to use its notes.`);

    } catch (e) {
      hideImportProgress();
      setStatus('error', 'Failed to parse PPTX: ' + e.message);
    } finally {
      // Cross-platform cleanup — fs.rmSync works on Mac and Windows (Node ≥ 14.14).
      try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch (_) {}
    }
  }

  function extractSlideTitle(xml) {
    const match = xml.match(/<p:ph[^>]*type="(?:title|ctrTitle)"[^>]*\/?>/);
    if (!match) return '';
    const spStart = xml.lastIndexOf('<p:sp>', match.index);
    const spEnd   = xml.indexOf('</p:sp>', match.index);
    if (spStart < 0 || spEnd < 0) return '';
    return extractXmlText(xml.slice(spStart, spEnd + 7));
  }

  function extractSlideNotes(xml) {
    // The notes body shape has idx="1"; the slide-image shape has idx="0" (no text).
    // Safest approach: find idx="1" shape and extract its text.
    // Fall back to full-XML extraction if shape isn't found.
    const match = xml.match(/<p:ph[^>]*idx="1"[^>]*\/?>/i);
    if (match) {
      const spStart = xml.lastIndexOf('<p:sp>', match.index);
      const spEnd   = xml.indexOf('</p:sp>', match.index);
      if (spStart >= 0 && spEnd >= 0) {
        return extractXmlText(xml.slice(spStart, spEnd + 7)).trim();
      }
    }
    // Fallback: all text in the notes XML (idx="0" shapes rarely carry <a:t> text)
    return extractXmlText(xml).trim();
  }

  function extractXmlText(xml) {
    const texts = [];
    const re = /<a:t[^>]*>([^<]*)<\/a:t>/g;
    let m;
    while ((m = re.exec(xml)) !== null) {
      const t = decodeXmlEntities(m[1]).trim();
      if (t) texts.push(t);
    }
    return texts.join(' ');
  }

  function decodeXmlEntities(str) {
    return str
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&apos;/g, "'")
      .replace(/&quot;/g, '"')
      .replace(/&#xD;|&#x0D;/g, '');
  }

  function escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function renderSlidePicker(slides) {
    el.slideList.innerHTML = '';

    slides.forEach((slide, idx) => {
      const card = document.createElement('div');
      card.className = 'slide-card' + (slide.notes ? '' : ' slide-card--no-notes');

      const titleHtml = slide.title
        ? `<span class="slide-title-text">${escapeHtml(slide.title)}</span>`
        : '';

      const notesHtml = slide.notes
        ? `<div class="slide-notes-text">${escapeHtml(slide.notes)}</div>`
        : '<span class="slide-no-notes">No speaker notes</span>';

      card.innerHTML = `
        <div class="slide-card-header">
          <span class="slide-num-badge">Slide ${slide.num}</span>
          ${titleHtml}
        </div>
        ${notesHtml}
      `;

      card.addEventListener('click', () => {
        loadSlide(idx);
        el.slidePicker.style.display = 'none';
      });

      el.slideList.appendChild(card);
    });

    el.slidePicker.style.display = 'flex';
  }

  // ─── Slide navigator helpers ──────────────────────────────────────────
  // Saves whatever is currently in the script field as the edited copy
  // of the currently-loaded slide. Lets users tweak per-slide and revisit later.
  function captureCurrentEdit() {
    if (!pptxSlides || currentSlideIdx < 0 || currentSlideIdx >= pptxSlides.length) return;
    const slideNum = pptxSlides[currentSlideIdx].num;
    slideEdits.set(slideNum, el.scriptText.value);
  }

  // Loads slide at `idx` into the script field. Restores the user's edited
  // copy if one exists; otherwise falls back to the original speaker notes.
  function loadSlide(idx) {
    if (!pptxSlides || idx < 0 || idx >= pptxSlides.length) return;
    captureCurrentEdit(); // save outgoing slide's edits first
    currentSlideIdx = idx;
    const slide = pptxSlides[idx];
    const text = slideEdits.has(slide.num) ? slideEdits.get(slide.num) : (slide.notes || '');
    el.scriptText.value = text;
    updateCharCount();
    updatePausePreview();
    updatePacingPanel();
    updateSlideNav();
    if (!text.trim()) {
      setStatus('warning', `Slide ${slide.num} has no speaker notes.`);
    } else {
      setStatus('idle', `Slide ${slide.num} loaded${slideEdits.has(slide.num) ? ' (with your edits)' : ''}.`);
    }
  }

  // Shows or hides the navigator strip and refreshes the counter, title, and
  // prev/next disabled state based on the current slide.
  function updateSlideNav() {
    if (!el.slideNav) return;
    const hasSlides = pptxSlides && pptxSlides.length && currentSlideIdx >= 0;
    if (!hasSlides) {
      el.slideNav.style.display = 'none';
      return;
    }
    const slide = pptxSlides[currentSlideIdx];
    el.slideNav.style.display = 'flex';
    el.slideNavNum.textContent = String(currentSlideIdx + 1);
    el.slideNavTotal.textContent = String(pptxSlides.length);
    el.slideNavTitle.textContent = slide.title || '';
    el.slideNavPrev.disabled = currentSlideIdx <= 0;
    el.slideNavNext.disabled = currentSlideIdx >= pptxSlides.length - 1;
  }

  // ─── Open folder in Finder / Explorer ───
  function openInFinder(folderPath) {
    if (!childProcess) return;
    const cmd = os.platform() === 'win32'
      ? `explorer "${folderPath.replace(/\//g, '\\')}"`
      : `open "${folderPath}"`;
    childProcess.exec(cmd);
  }

  // ─── Output folder helpers ───
  function updateSpecificFolderVisibility() {
    el.specificFolderRow.style.display = el.saveSpecific.checked ? 'flex' : 'none';
  }

  function resolveOutputDir() {
    if (!el.autoSaveVo.checked) {
      ensureOutputDir();
      return Promise.resolve(outputDir);
    }

    return new Promise((resolve) => {
      const fallbackToDesktop = (reason) => {
        const desktop = path.join(os.homedir(), 'Desktop');
        setStatus('warning', reason + ' — saving to Desktop.');
        resolve(desktop);
      };

      cs.evalScript('getProjectFolder()', result => {
        if (!result || result.startsWith('ERROR:')) {
          fallbackToDesktop(result ? result.replace('ERROR:', '').trim() : 'Could not get project folder');
          return;
        }

        const rootFolder = result.replace('OK:', '').trim();

        // NVIDIA Academy projects use 02_Footage; generic projects use Footage.
        // Pick whichever footage dir already exists; default to 02_Footage when
        // neither is present so the first save uses the NVIDIA convention.
        const footageDirName = fs.existsSync(path.join(rootFolder, '02_Footage'))
          ? '02_Footage'
          : fs.existsSync(path.join(rootFolder, 'Footage'))
            ? 'Footage'
            : '02_Footage';
        const voFolder = path.join(rootFolder, footageDirName, 'Audio', 'VO');

        try {
          if (!fs.existsSync(voFolder)) {
            fs.mkdirSync(voFolder, { recursive: true });
          }
          resolve(voFolder);
        } catch (e) {
          fallbackToDesktop('Could not create VO folder (' + e.message + ')');
        }
      });
    });
  }

  // ─── Output directory ───
  function ensureOutputDir() {
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
  }

  function updateOutputPathDisplay() {
    el.outputPath.textContent = outputDir;
    el.outputPath.title = outputDir;
  }

  function changeOutputDir() {
    const result = window.cep.fs.showOpenDialogEx(
      false, true, 'Choose output folder', outputDir, []
    );

    if (result && result.data && result.data.length > 0) {
      outputDir = result.data[0];
      localStorage.setItem('el_output_dir', outputDir);
      ensureOutputDir();
      updateOutputPathDisplay();
    }
  }

  // ─── History ───
  function addToHistory(voiceId, text, filePath, layerName) {
    const voiceName = voices.find(v => v.voice_id === voiceId)?.name || voiceId;
    const item = {
      voiceName,
      text: text.slice(0, 60) + (text.length > 60 ? '…' : ''),
      filePath,
      layerName,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    history.unshift(item);
    if (history.length > 10) history.pop();
    localStorage.setItem('el_history', JSON.stringify(history));
    renderHistory();
    // Auto-expand history section on new generation
    if (el.historyBody && el.historyBody.style.maxHeight === '0px') {
      el.historyBody.style.maxHeight = el.historyBody.scrollHeight + 'px';
      if (el.historyArrow) el.historyArrow.style.transform = '';
    }
  }

  function renderHistory() {
    if (!el.historyList) return;
    el.historyList.innerHTML = '';

    if (history.length === 0) {
      el.historyList.innerHTML = '<div style="color:var(--text-muted);font-size:11px;padding:4px 0">No generations yet.</div>';
      return;
    }

    history.forEach(item => {
      const div = document.createElement('div');
      div.className = 'history-item';
      div.title = item.filePath ? 'Click to reveal in Finder' : '';
      div.innerHTML = `
        <span class="history-voice">${item.voiceName}</span>
        <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${item.text}</span>
        <span class="history-time">${item.time}</span>
      `;
      if (item.filePath) {
        div.style.cursor = 'pointer';
        div.addEventListener('click', () => revealInFinder(item.filePath));
      }
      el.historyList.appendChild(div);
    });
  }

  function revealInFinder(filePath) {
    if (!filePath || !childProcess) return;
    const isWin = os.platform() === 'win32';
    if (isWin) {
      childProcess.exec(`explorer /select,"${filePath}"`);
    } else {
      childProcess.exec(`open -R ${sq(filePath)}`);
    }
  }

  // ─── Character count ───
  function updateCharCount() {
    const len = el.scriptText.value.length;
    const max = 5000;
    el.charCount.textContent = `${len} / ${max}`;
    el.charCount.classList.toggle('warn', len > max * 0.9);
    if (len > max) {
      el.scriptText.value = el.scriptText.value.slice(0, max);
    }
  }

  // ─── First N words of a sentence (for timeline marker labels) ───────────
  // Strips pacing tags like [slowly, deliberately] before extracting words.
  function firstWords(text, n) {
    return text.trim()
      .replace(/\[.*?\]/g, '')
      .trim()
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, n)
      .join(' ');
  }

  // ─── Sentence splitting — robust to messy paste from PPT/Word ──────────
  // Strategy:
  //   1) Split on line breaks first — any newline is a sentence boundary by user intent
  //      (bulleted/numbered lists, paragraph breaks, etc.)
  //   2) Strip leading list markers from each line: "1.", "1)", "•", "-", "*", "–"
  //   3) Within each line, further split on punctuation followed by EITHER whitespace +
  //      capital OR directly by a capital (handles paste-lost-spaces case).
  // Acronym guard: negative lookbehind on uppercase prevents splitting "U.S.A.".
  // Abbreviation guard: Mr./Dr./i.e./etc. handled as post-filter.
  const ABBREV = /\b(?:Mr|Mrs|Ms|Dr|Sr|Jr|Prof|St|vs|etc|i\.e|e\.g)\.$/i;
  const LIST_MARKER = /^(?:\d+[.)]\s*|[•·*\-–—]\s*)/;
  // Skip lines that contain no actual letter/digit content — catches lines that have
  // only zero-width spaces (U+200B), word joiners, BOMs, or pure punctuation.
  // Unicode-aware: \p{L} matches any letter, \p{N} any number.
  const HAS_CONTENT = /[\p{L}\p{N}]/u;

  function splitSentences(text) {
    if (!text || !text.trim()) return [];
    const lines = text.split(/\r?\n+/);
    const out = [];
    for (let raw of lines) {
      let line = raw.trim();
      if (!HAS_CONTENT.test(line)) continue;
      line = line.replace(LIST_MARKER, '').trim();
      if (!HAS_CONTENT.test(line)) continue;
      // Further split within the line on inline punctuation boundaries
      const re = /(?<![A-Z])[.!?]+["')\]]?(?:\s+(?=["'(\[]?[A-Z0-9])|(?=[A-Z]))/g;
      let last = 0, m;
      while ((m = re.exec(line)) !== null) {
        const head = line.slice(last, m.index + m[0].length).trim();
        const tail = line.slice(0, m.index + 1);
        if (ABBREV.test(tail)) continue;
        if (HAS_CONTENT.test(head)) out.push(head);
        last = m.index + m[0].length;
      }
      const tail = line.slice(last).trim();
      if (HAS_CONTENT.test(tail)) out.push(tail);
    }
    return out;
  }

  // ─── Pacing panel — per-sentence speed pills (v3 only) ───
  function updatePacingPanel() {
    if (!el.pacingPanel) return;
    const text = el.scriptText.value;
    const isV3 = el.modelSelect.value === 'eleven_v3';

    if (!isV3 || !text.trim()) {
      el.pacingPanel.style.display = 'none';
      return;
    }

    // Defensive: filter out any empty/whitespace-only entries before rendering rows.
    const sentences = splitSentences(text).filter(s => s && s.trim());
    if (sentences.length === 0) {
      el.pacingPanel.style.display = 'none';
      return;
    }

    // Garbage-collect entries that no longer match any current sentence
    const seen = new Set(sentences);
    for (const k of pacingMap.keys()) if (!seen.has(k)) pacingMap.delete(k);

    const escapeHtml = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const rows = sentences.map((sent, i) => {
      const speed = pacingMap.get(sent) || 'normal';
      const trimmed = sent.length > 180 ? sent.slice(0, 177) + '…' : sent;
      return `
        <div class="pacing-row" data-idx="${i}" data-speed="${speed}" data-key="${escapeHtml(sent)}">
          <span class="pacing-num">${i + 1}</span>
          <div class="pacing-text">${escapeHtml(trimmed)}</div>
          <div class="pacing-pills" role="group" aria-label="Pacing">
            <button class="speed-pill ${speed === 'slow' ? 'active' : ''}" data-speed="slow" type="button" title="Slower delivery"><span class="speed-emoji">🐢</span>Slow</button>
            <button class="speed-pill ${speed === 'normal' ? 'active' : ''}" data-speed="normal" type="button" title="Default pace">Normal</button>
            <button class="speed-pill ${speed === 'fast' ? 'active' : ''}" data-speed="fast" type="button" title="Faster delivery"><span class="speed-emoji">⚡</span>Fast</button>
          </div>
        </div>`;
    }).join('');

    el.pacingList.innerHTML = rows;
    // Stagger entrance
    Array.from(el.pacingList.children).forEach((row, i) => {
      row.style.animationDelay = `${Math.min(i * 40, 400)}ms`;
    });

    // Wire pill clicks (event delegation would also work; this is fine for small N)
    el.pacingList.querySelectorAll('.speed-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        const row = btn.closest('.pacing-row');
        const key = row.getAttribute('data-key');
        const speed = btn.getAttribute('data-speed');
        if (speed === 'normal') pacingMap.delete(key);
        else pacingMap.set(key, speed);
        updatePacingPanel();
      });
    });

    const adjusted = sentences.filter(s => pacingMap.has(s)).length;
    el.pacingCount.textContent = adjusted > 0
      ? `· ${adjusted} of ${sentences.length} adjusted`
      : `· ${sentences.length} sentence${sentences.length === 1 ? '' : 's'}`;
    el.pacingPanel.style.display = 'block';
  }

  // Apply per-sentence pacing tags before sending to API.
  // v3 audio tags are interpretive — single tags often get ignored.
  // Compound tags + reinforcement at the end of the sentence improve hit-rate.
  function applyPacing(text) {
    if (el.modelSelect.value !== 'eleven_v3') return text;
    if (pacingMap.size === 0) return text;
    const sentences = splitSentences(text);
    if (sentences.length === 0) return text;
    return sentences.map(s => {
      const speed = pacingMap.get(s);
      if (speed === 'slow') {
        // Compound directive + soft ellipsis hint reinforces slow delivery.
        const body = s.replace(/([.!?])\s*$/, ' …$1');
        return `[slowly, deliberately] ${body}`;
      }
      if (speed === 'fast') {
        return `[quickly, energetically] ${s}`;
      }
      return s;
    }).join(' ');
  }

  // ─── Pause preview — shows where pauses will be inserted ───
  function updatePausePreview() {
    if (!el.pausePreview) return;
    const text = el.scriptText.value;

    if (!el.addPauses.checked || !text.trim()) {
      el.pausePreview.style.display = 'none';
      return;
    }

    const isV3 = el.modelSelect.value === 'eleven_v3';
    const marker = isV3 ? '[pause]' : '--';
    const escapeHtml = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const markerHtml = (label, idx) =>
      `<span class="pause-marker" style="animation-delay:0s,${(idx * 80) + 350}ms;">` +
        `<span class="pause-bars" aria-hidden="true">` +
          `<span></span><span></span><span></span>` +
        `</span>` +
        `<span class="pause-label">${escapeHtml(label)}</span>` +
      `</span>`;

    // Mirror the actual pause-insertion at TTS time: split into sentences,
    // then join with marker HTML between them. Same source of truth as splitSentences,
    // so list markers / newlines / no-space pastes all show consistent pause counts.
    const sentences = splitSentences(text);
    let count = 0;
    const html = sentences.map(s => escapeHtml(s)).reduce((acc, s, i) => {
      if (i === 0) return s;
      const idx = count++;
      return `${acc} ${markerHtml(marker, idx)} ${s}`;
    }, '');

    if (count === 0) {
      el.pausePreview.style.display = 'none';
      return;
    }

    el.pausePreviewText.innerHTML = html;
    el.pausePreviewCount.textContent = `· ${count} pause${count === 1 ? '' : 's'}`;
    el.pausePreview.style.display = 'block';
  }

  // ─── Import progress bar ───
  function showImportProgress(pct) {
    if (!el.importProgress) return;
    el.importProgress.style.display = 'block';
    el.importProgressFill.style.width = Math.min(100, pct) + '%';
  }

  function hideImportProgress() {
    if (!el.importProgress) return;
    el.importProgress.style.display = 'none';
    el.importProgressFill.style.width = '0%';
  }


  // ─── Auto-update check (boot + every 30 min) ───
  function _verCmp(a, b) {
    const pa = String(a).split('.').map(n => parseInt(n, 10) || 0);
    const pb = String(b).split('.').map(n => parseInt(n, 10) || 0);
    for (let i = 0; i < 3; i++) {
      if ((pa[i] || 0) > (pb[i] || 0)) return  1;
      if ((pa[i] || 0) < (pb[i] || 0)) return -1;
    }
    return 0;
  }

  // Tries each manifest URL in order; returns the first one that parses as JSON.
  // Returns { data, host } on success or { error: <last error message> } on failure.
  // Logs every attempt to console for diagnostics in DevTools.
  // The GitHub Contents API URL is special-cased: response is base64-encoded
  // inside a JSON envelope, so we decode it before returning.
  async function _fetchLatestJson() {
    const cacheBust = '?t=' + Date.now() + '-' + Math.random().toString(36).slice(2);
    let lastErr = '';
    for (const baseUrl of EL_LATEST_URLS) {
      const isGitHubApi = /^https:\/\/api\.github\.com\//.test(baseUrl);
      // GitHub API ignores cache-bust query params and returns fresh data anyway.
      // For raw + jsDelivr, the cache-bust still helps with intermediate proxies.
      const url = isGitHubApi ? baseUrl : (baseUrl + (baseUrl.includes('?') ? '&' : '?') + cacheBust.slice(1));
      const host = (baseUrl.match(/^https?:\/\/([^/]+)/) || [, baseUrl])[1];
      try {
        const headers = { 'Cache-Control': 'no-cache, no-store, must-revalidate', 'Pragma': 'no-cache' };
        if (isGitHubApi) headers['Accept'] = 'application/vnd.github.v3+json';
        const res = await fetch(url, { cache: 'no-store', headers });
        if (!res.ok) {
          lastErr = `${host} → HTTP ${res.status}`;
          console.warn('[ElevenLabs] manifest fetch failed:', lastErr);
          continue;
        }
        let data;
        if (isGitHubApi) {
          const envelope = await res.json();
          if (envelope.encoding !== 'base64' || !envelope.content) {
            lastErr = `${host} → unexpected API response shape`;
            console.warn('[ElevenLabs] manifest fetch failed:', lastErr);
            continue;
          }
          // GitHub returns base64 with embedded newlines — strip whitespace before decode
          data = JSON.parse(atob(envelope.content.replace(/\s/g, '')));
        } else {
          data = await res.json();
        }
        console.log(`[ElevenLabs] manifest fetched from ${host} → v${data && data.version}`);
        return { data, host };
      } catch (e) {
        lastErr = `${host} → ${e && e.message ? e.message : String(e)}`;
        console.warn('[ElevenLabs] manifest fetch failed:', lastErr);
      }
    }
    return { error: lastErr || 'all manifest hosts unreachable' };
  }

  // Helper: paints the install-panel "Update Now" button to match current state.
  // Skips the paint while an install is in flight (data-installing flag set).
  function _setAutoBtnState(state, version) {
    if (!el.installAutoBtn) return;
    if (el.installAutoBtn.dataset.installing === '1') return;
    switch (state) {
      case 'available':
        el.installAutoBtn.disabled = false;
        el.installAutoBtn.textContent = `Update to v${version}`;
        break;
      case 'uptodate':
        el.installAutoBtn.disabled = true;
        el.installAutoBtn.textContent = `Up to date (v${version})`;
        break;
      case 'unreachable':
        el.installAutoBtn.disabled = true;
        el.installAutoBtn.textContent = 'Update server unreachable';
        break;
      case 'checking':
        el.installAutoBtn.disabled = true;
        el.installAutoBtn.textContent = 'Checking…';
        break;
    }
  }

  // checkForUpdate(opts) — set opts.manual=true when invoked by the user clicking
  // "Check for updates" so we surface a visible result (success / no-update / error)
  // in the install panel instead of failing silently.
  async function checkForUpdate(opts) {
    const manual = !!(opts && opts.manual);
    const result = await _fetchLatestJson();
    if (result.error || !result.data || !result.data.version) {
      const msg = result.error || 'manifest missing version field';
      console.warn('[ElevenLabs] update check failed:', msg);
      if (manual) setUpdateStatus(`Couldn't reach update server (${msg}). Use manual install below.`);
      _setAutoBtnState('unreachable');
      return;
    }
    const data = result.data;
    const remote = String(data.version).trim();
    if (_verCmp(remote, EL_VERSION) <= 0) {
      if (manual) setUpdateStatus(`You're up to date — running v${EL_VERSION}.`);
      _setAutoBtnState('uptodate', EL_VERSION);
      return;
    }
    // Manual checks override the dismiss flag — the user explicitly asked.
    if (!manual && localStorage.getItem(EL_DISMISS_KEY) === remote) {
      // Even if the banner is dismissed, reflect the available update on the
      // install panel button so it's still actionable from the gear icon.
      _setAutoBtnState('available', remote);
      if (el.updateBanner) {
        el.updateBanner.dataset.version = remote;
        el.updateBanner.dataset.updateUrl = data.updateUrl || '';
      }
      return;
    }
    if (!el.updateBanner) return;
    el.updateBannerVersion.textContent = 'v' + remote;
    el.updateBanner.dataset.version = remote;
    el.updateBanner.dataset.updateUrl = data.updateUrl || '';
    // Reset banner button state in case it was previously locked while installing
    el.updateBannerBtn.disabled = false;
    el.updateBannerBtn.textContent = 'Update';
    el.updateBanner.classList.add('show');
    _setAutoBtnState('available', remote);
    console.log(`[ElevenLabs] Update available: v${remote} (installed v${EL_VERSION})`);
    if (manual) setUpdateStatus(`Update v${remote} available — banner shown at top.`);
  }

  // Diagnostic helpers — callable from DevTools console if needed
  window.elDiag = {
    check:  () => checkForUpdate(),
    clear:  () => localStorage.removeItem(EL_DISMISS_KEY),
    state:  () => ({ installed: EL_VERSION, dismissed: localStorage.getItem(EL_DISMISS_KEY), banner: el.updateBanner ? el.updateBanner.classList.contains('show') : 'missing' })
  };

  // ─── One-click in-panel update ───
  // Fetches the latest .zip from the GitHub releases repo (no SharePoint auth
  // needed) and installs it in place.
  // Builds a list of mirror URLs for the update zip — same idea as the manifest
  // fallback. If updateUrl points at raw.githubusercontent.com we try jsDelivr
  // as a backup. (The zip file is versioned, so jsDelivr's cache is fine.)
  function _zipUrlCandidates(updateUrl) {
    const m = updateUrl && updateUrl.match(/^https?:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/);
    if (!m) return [updateUrl].filter(Boolean);
    const [, user, repo, branch, file] = m;
    return [
      updateUrl,
      `https://cdn.jsdelivr.net/gh/${user}/${repo}@${branch}/${file}`
    ];
  }

  async function fetchAndInstallUpdate(updateUrl, version) {
    const tmpZip = path.join(os.tmpdir(), `el_update_${Date.now()}.zip`);
    const candidates = _zipUrlCandidates(updateUrl);
    const verLabel = version ? `v${version}` : 'update';
    let lastErr = '';
    let buf = null;
    setUpdateStatus(`Downloading ${verLabel}…`);
    setStatus('loading', `Downloading ${verLabel}…`);
    for (const url of candidates) {
      const host = (url.match(/^https?:\/\/([^/]+)/) || [, url])[1];
      try {
        const res = await fetch(url, { cache: 'no-store' });
        if (!res.ok) {
          lastErr = `${host} → HTTP ${res.status}`;
          console.warn('[ElevenLabs] zip fetch failed:', lastErr);
          continue;
        }
        buf = Buffer.from(await res.arrayBuffer());
        console.log(`[ElevenLabs] zip downloaded from ${host} (${buf.length} bytes)`);
        break;
      } catch (e) {
        lastErr = `${host} → ${e && e.message ? e.message : String(e)}`;
        console.warn('[ElevenLabs] zip fetch failed:', lastErr);
      }
    }
    try {
      if (!buf) throw new Error(lastErr || 'all mirrors unreachable');
      setUpdateStatus(`Installing ${verLabel}…`);
      setStatus('loading', `Installing ${verLabel}…`);
      fs.writeFileSync(tmpZip, buf);
      await installFromZip(tmpZip);
      setUpdateStatus('');
      setStatus('success', `${verLabel.charAt(0).toUpperCase() + verLabel.slice(1)} installed.`);
      _showInstallSuccess(version || (el.updateBanner && el.updateBanner.dataset.version));
    } catch (e) {
      setUpdateStatus(`Update to ${verLabel} failed: ` + e.message);
      setStatus('error', `Update to ${verLabel} failed: ` + e.message);
    } finally {
      try { fs.unlinkSync(tmpZip); } catch (_) {}
    }
  }

  // ─── Success card ───
  function _showInstallSuccess(version) {
    if (!el.installSuccess) return;
    if (version) el.installSuccessVersion.textContent = 'v' + version;
    el.installSuccess.style.display = 'flex';
    // Hide the "pick a method" UI now that the install is done
    const auto   = document.querySelector('.install-method--auto');
    const manual = document.querySelector('.install-method--manual');
    const sep    = document.querySelector('.install-divider');
    const sub    = document.getElementById('install-subtitle');
    if (auto)   auto.style.display = 'none';
    if (manual) manual.style.display = 'none';
    if (sep)    sep.style.display = 'none';
    if (sub)    sub.textContent = 'Done — reload to start using the new version';
  }

  function bindUpdateBanner() {
    if (!el.updateBannerBtn) return;

    // Banner Update button — opens the install panel where the user picks a method
    el.updateBannerBtn.addEventListener('click', () => {
      if (el.updatePanel) el.updatePanel.classList.add('visible');
      if (el.updateBtn)   el.updateBtn.classList.add('active');
      if (el.updateBanner) el.updateBanner.classList.remove('show');
    });

    el.updateBannerDismiss.addEventListener('click', () => {
      const v = el.updateBanner.dataset.version;
      if (v) localStorage.setItem(EL_DISMISS_KEY, v);
      el.updateBanner.classList.remove('show');
    });

    // Manual "Check for updates" — surfaces visible status (success/up-to-date/
    // network error) instead of failing silently. Crucial for Windows users
    // whose corp network sometimes blocks raw.githubusercontent.com.
    if (el.installCheckBtn) {
      el.installCheckBtn.addEventListener('click', async () => {
        el.installCheckBtn.disabled = true;
        const oldLabel = el.installCheckBtn.textContent;
        el.installCheckBtn.textContent = 'Checking…';
        setUpdateStatus('Checking for updates…');
        await checkForUpdate({ manual: true });
        el.installCheckBtn.disabled = false;
        el.installCheckBtn.textContent = oldLabel;
      });
    }

    // "Update Now" auto-update button inside the install panel
    if (el.installAutoBtn) {
      el.installAutoBtn.addEventListener('click', async () => {
        // Defensive — should never fire because the button is disabled when
        // there's no update, but guard anyway.
        if (el.installAutoBtn.disabled) return;
        const url = (el.updateBanner && el.updateBanner.dataset.updateUrl) || '';
        const ver = (el.updateBanner && el.updateBanner.dataset.version) || '';
        if (!url) {
          setUpdateStatus(`You're already on the latest version (v${EL_VERSION}).`);
          return;
        }
        el.installAutoBtn.dataset.installing = '1';
        el.installAutoBtn.disabled = true;
        el.installAutoBtn.textContent = ver ? `Installing v${ver}…` : 'Installing…';
        try {
          await fetchAndInstallUpdate(url, ver);
        } finally {
          delete el.installAutoBtn.dataset.installing;
        }
      });
    }

    // Reload Plugin button — just reload the panel, picks up new HTML/CSS/JS/JSX
    if (el.installReloadBtn) {
      el.installReloadBtn.addEventListener('click', () => {
        location.reload();
      });
    }

    // Later button — close the install panel + success card, leave panel updated
    if (el.installSuccessClose) {
      el.installSuccessClose.addEventListener('click', () => {
        if (el.updatePanel) el.updatePanel.classList.remove('visible');
        if (el.updateBtn)   el.updateBtn.classList.remove('active');
      });
    }
  }

  // ─── Manual install ───
  function setUpdateStatus(msg) {
    if (el.updateStatusText) el.updateStatusText.textContent = msg;
  }

  async function installFromZip(zipPath) {
    const isWin = os.platform() === 'win32';
    const tmpZip = path.join(os.tmpdir(), `el_update_${Date.now()}.zip`);
    const tmpDir = tmpZip.replace('.zip', '_extracted');

    try {
      fs.copyFileSync(zipPath, tmpZip);
      setUpdateStatus('Extracting…');

      fs.mkdirSync(tmpDir, { recursive: true });
      if (isWin) {
        childProcess.execSync(
          `powershell -command "Expand-Archive -Path '${tmpZip.replace(/'/g, "''")}' -DestinationPath '${tmpDir.replace(/'/g, "''")}' -Force"`,
          { timeout: 30000 }
        );
      } else {
        childProcess.execSync(`unzip -q ${sq(tmpZip)} -d ${sq(tmpDir)}`, { timeout: 30000 });
      }

      const entries = fs.readdirSync(tmpDir);
      const pluginFolder = entries.find(e =>
        fs.statSync(path.join(tmpDir, e)).isDirectory() &&
        fs.existsSync(path.join(tmpDir, e, 'CSXS', 'manifest.xml'))
      );
      if (!pluginFolder) throw new Error('Plugin folder not found inside ZIP.');

      const srcPluginPath = path.join(tmpDir, pluginFolder);
      const installedPath = cs.getSystemPath(SystemPath.EXTENSION);
      setUpdateStatus('Installing…');

      if (isWin) {
        childProcess.execSync(`rmdir /s /q "${installedPath}"`, { timeout: 10000 });
        childProcess.execSync(`xcopy /e /i /q "${srcPluginPath}" "${installedPath}\\"`, { timeout: 15000 });
      } else {
        childProcess.execSync(`rm -rf ${sq(installedPath)}`, { timeout: 10000 });
        childProcess.execSync(`cp -r ${sq(srcPluginPath)} ${sq(installedPath)}`, { timeout: 15000 });
      }

      for (const v of [9, 10, 11, 12]) {
        try {
          if (isWin) {
            childProcess.execSync(`reg add "HKCU\\SOFTWARE\\Adobe\\CSXS.${v}" /v PlayerDebugMode /t REG_SZ /d 1 /f`, { timeout: 3000 });
          } else {
            childProcess.execSync(`defaults write com.adobe.CSXS.${v} PlayerDebugMode 1`, { timeout: 3000 });
          }
        } catch (_) {}
      }
    } finally {
      try { fs.unlinkSync(tmpZip); } catch (_) {}
      try {
        if (isWin) childProcess.execSync(`rmdir /s /q "${tmpDir}"`, { timeout: 5000 });
        else childProcess.execSync(`rm -rf ${sq(tmpDir)}`, { timeout: 5000 });
      } catch (_) {}
    }
  }

  function browseAndInstallZip() {
    cs.evalScript('selectZipFile()', async result => {
      if (!result || result === 'CANCELLED' || result.trim() === '') return;
      if (result.startsWith('ERROR:')) {
        setUpdateStatus('File picker error: ' + result.replace('ERROR:', '').trim());
        return;
      }
      const zipPath = result.replace('OK:', '').trim();
      if (el.installZipBtn) {
        el.installZipBtn.disabled = true;
        el.installZipBtn.textContent = 'Installing…';
      }
      setUpdateStatus('Copying…');
      try {
        await installFromZip(zipPath);
        setUpdateStatus('');
        setStatus('success', 'Update installed.');
        _showInstallSuccess(el.updateBanner && el.updateBanner.dataset.version);
      } catch (e) {
        setUpdateStatus('Install failed: ' + e.message);
        setStatus('error', 'Install failed: ' + e.message);
      } finally {
        if (el.installZipBtn) {
          el.installZipBtn.disabled = false;
          el.installZipBtn.textContent = 'Browse for ZIP…';
        }
      }
    });
  }

  // ─── Status bar ───
  function setStatus(type, message) {
    el.statusBar.className = `status-bar ${type}`;
    el.statusText.textContent = message;
  }

  // ─── Boot ───
  document.addEventListener('DOMContentLoaded', init);

})();
