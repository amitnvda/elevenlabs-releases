/**
 * ElevenLabs Voiceover - ExtendScript
 * Handles audio import and timeline placement for After Effects and Premiere Pro.
 */

// --- Ping (diagnostic) ---
function pingJSX() {
    return "OK:alive";
}

// --- App detection: CompItem only exists in After Effects ---
function isPremiereHost() {
    return (typeof CompItem === "undefined");
}

/**
 * Premiere: find the TrackItem in any audio track whose start time is
 * within 100 ms of targetSecs. Used to attach clip-level markers that
 * travel with the clip when it's moved on the timeline.
 */
function _findTrackItemAtSecs(seq, targetSecs) {
    try {
        var numTracks = seq.audioTracks.numTracks;
        for (var t = 0; t < numTracks; t++) {
            var clips = seq.audioTracks[t].clips;
            for (var c = 0; c < clips.numItems; c++) {
                var clip = clips[c];
                if (Math.abs(clip.start.seconds - targetSecs) < 0.1) {
                    return clip;
                }
            }
        }
    } catch (e) {}
    return null;
}

/**
 * Multi-clip entry point: imports a set of pre-split individual audio files
 * and places them sequentially on the timeline starting at the playhead.
 * Each file is a complete standalone clip — no shared project item, no
 * setInPoint/setOutPoint juggling that caused Premiere to corrupt clip ranges.
 */
function importAndPlaceAudioMultiple(filesCsv, labelsCsv, durationsCsv) {
    var files     = filesCsv.split('|');
    var labels    = (labelsCsv    && labelsCsv.length)    ? labelsCsv.split('|')    : [];
    var durations = (durationsCsv && durationsCsv.length) ? durationsCsv.split('|') : [];
    if (isPremiereHost()) {
        return importAndPlaceAudioMultiplePremiere(files, labels, durations);
    } else {
        return importAndPlaceAudioMultipleAE(files, labels, durations);
    }
}

function importAndPlaceAudioMultipleAE(files, labels, durations) {
    try {
        var comp = app.project.activeItem;
        if (typeof CompItem === "undefined" || !(comp instanceof CompItem)) {
            return "ERROR:No active composition";
        }
        app.beginUndoGroup("ElevenLabs Voiceover (Split)");
        var basePlayhead = comp.time;
        var offset = 0;
        var placed = 0;
        for (var i = 0; i < files.length; i++) {
            var f = new File(files[i]);
            if (!f.exists) continue;
            var opts = new ImportOptions(f);
            opts.sequence = false;
            opts.forceAlphabetical = false;
            var item = app.project.importFile(opts);

            // Prefer JS-supplied duration — item.duration can return 0 for
            // freshly imported WAV files before AE has fully processed them.
            var clipDur = (durations[i]) ? parseFloat(durations[i]) : 0;
            if (!clipDur || clipDur <= 0) clipDur = item.duration;

            var clipStart = basePlayhead + offset;
            var clipEnd   = clipStart + clipDur;

            if (clipEnd > comp.duration) comp.duration = clipEnd;

            var layer = comp.layers.add(item);
            // Must set all three: startTime anchors source→comp mapping,
            // inPoint/outPoint set the active range in the comp timeline.
            // Without explicit inPoint/outPoint, AE leaves them at comp.time
            // and all clips stack at the same position regardless of startTime.
            layer.startTime = clipStart;
            layer.inPoint   = clipStart;
            layer.outPoint  = clipEnd;
            layer.name = "EL " + (i + 1) + ": " + item.name.replace(/\.[^.]+$/, "");

            var label = labels[i] || "";
            if (label) {
                try {
                    var mv = new MarkerValue(label);
                    layer.property("Marker").setValueAtTime(clipStart, mv);
                } catch(me) {}
            }
            offset += clipDur;
            placed++;
        }
        app.endUndoGroup();
        return "OK:" + placed + " clips";
    } catch(e) {
        return "ERROR:" + e.message;
    }
}

function importAndPlaceAudioMultiplePremiere(files, labels, durations) {
    var log = [];
    try {
        try { app.enableQE(); } catch(e) {}
        var seq = app.project.activeSequence;
        if (!seq) return "ERROR:No active sequence";

        var root = app.project.rootItem;
        var voBin = null;
        for (var i = 0; i < root.children.numItems; i++) {
            if (root.children[i].name === "VO") { voBin = root.children[i]; break; }
        }
        if (!voBin) voBin = root.createBin("VO");

        var TICKS_PER_SECOND = 254016000000;
        var currentSecs = seq.getPlayerPosition().seconds;
        var inserted = 0;
        var firstName = "";

        for (var k = 0; k < files.length; k++) {
            var audioFile = new File(files[k]);
            if (!audioFile.exists) { log.push("clip" + k + ":missing"); continue; }

            var countBefore = voBin.children.numItems;
            app.project.importFiles([files[k]], true, voBin, false);

            var projectItem = null;
            var fn = audioFile.name;
            var fnBase = fn.replace(/\.[^.]+$/, "");
            for (var j = 0; j < voBin.children.numItems; j++) {
                var n = voBin.children[j].name;
                if (n === fn || n === fnBase) { projectItem = voBin.children[j]; break; }
            }
            if (!projectItem && voBin.children.numItems > countBefore) {
                projectItem = voBin.children[voBin.children.numItems - 1];
            }
            if (!projectItem) { log.push("clip" + k + ":not-found"); continue; }
            if (k === 0) firstName = projectItem.name;

            var insertTicks = String(Math.floor(currentSecs * TICKS_PER_SECOND));
            try {
                seq.insertClip(projectItem, insertTicks, -1, 0);
                inserted++;

                // Advance position using the actual clip end from the TrackItem
                var trackItem = _findTrackItemAtSecs(seq, currentSecs);
                var label = labels[k] || "";
                if (trackItem) {
                    if (label) {
                        try { var cm = trackItem.markers.createMarker(0); cm.name = label; } catch(me) {}
                    }
                    currentSecs = trackItem.end.seconds;
                } else {
                    // Fallback: use JS-supplied duration, then source item, then rough guess
                    var fbDur = (durations && durations[k]) ? parseFloat(durations[k]) : 0;
                    if (!fbDur || fbDur <= 0) { try { fbDur = projectItem.getOutPoint(1).seconds; } catch(e) { fbDur = 5; } }
                    currentSecs += fbDur;
                }
            } catch(insertErr) {
                log.push("clip" + k + ":fail=" + insertErr.message);
            }
        }

        if (inserted === 0) return "ERROR:[" + log.join(",") + "] no clips inserted";
        return "OK:[" + log.join(",") + "] " + inserted + " clips - " + firstName;
    } catch(e) {
        return "ERROR:[" + log.join(",") + "] " + e.message;
    }
}

/**
 * Unified entry point -- routes to the correct host implementation.
 * @param {string} filePath - Absolute path to the .mp3 file
 * @returns {string} "OK:<layerName>" on success, "ERROR:<message>" on failure
 */
function importAndPlaceAudio(filePath, markerLabel, clipDuration) {
    if (isPremiereHost()) {
        return importAndPlaceAudioPremiere(filePath, markerLabel);
    } else {
        return importAndPlaceAudioAE(filePath, markerLabel, clipDuration);
    }
}

/**
 * Split-clip entry point -- imports the audio once and places multiple
 * trimmed layers/clips on the timeline at sentence boundaries.
 * @param {string} filePath - Absolute path to the .mp3 file
 * @param {string} cutTimesCsv - Comma-separated end-times in seconds (e.g. "2.3,4.7,8.1")
 * @returns {string} "OK:<info>" on success, "ERROR:<message>" on failure
 */
function importAndPlaceAudioSplit(filePath, cutTimesCsv, labelsCsv) {
    var cutTimes = [];
    var parts = cutTimesCsv.split(",");
    for (var i = 0; i < parts.length; i++) {
        var t = parseFloat(parts[i]);
        if (!isNaN(t)) cutTimes.push(t);
    }
    if (cutTimes.length === 0) return "ERROR:No cut times provided";

    if (isPremiereHost()) {
        return importAndPlaceAudioSplitPremiere(filePath, cutTimes, labelsCsv);
    } else {
        return importAndPlaceAudioSplitAE(filePath, cutTimes, labelsCsv);
    }
}

/**
 * After Effects: import audio once, create one trimmed layer per sentence.
 * All layers share the same source and startTime; each has different inPoint/outPoint.
 */
function importAndPlaceAudioSplitAE(filePath, cutTimes, labelsCsv) {
    try {
        var audioFile = new File(filePath);
        if (!audioFile.exists) return "ERROR:File not found: " + filePath;

        var comp = app.project.activeItem;
        if (typeof CompItem === "undefined" || !(comp instanceof CompItem)) {
            return "ERROR:No active composition";
        }

        var importOptions = new ImportOptions(audioFile);
        importOptions.sequence = false;
        importOptions.forceAlphabetical = false;
        var audioItem = app.project.importFile(importOptions);

        var labels = (labelsCsv && labelsCsv.length) ? labelsCsv.split("|") : [];

        app.beginUndoGroup("ElevenLabs Voiceover (Split)");
        var basePlayhead = comp.time;
        var baseName = audioItem.name.replace(/\.[^.]+$/, "");
        var sourceDuration = audioItem.duration;
        // Extend comp if audio would be clipped at the comp boundary.
        var neededDuration = basePlayhead + sourceDuration;
        if (neededDuration > comp.duration) {
            comp.duration = neededDuration;
        }
        // cutTimes = intermediate boundaries only. N cuts -> N+1 clips.
        // The last clip extends to the audio's full source duration (not the last
        // intermediate cut), preserving tail silence/decay so it doesn't sound abrupt.
        // Non-last clips get an extra TAIL_SECS of silence so the voice decay
        // isn't clipped at the exact sentence boundary.
        var prevCut = 0;
        var n = cutTimes.length;
        var placed = 0;
        for (var i = 0; i <= n; i++) {
            var thisCut = (i < n) ? cutTimes[i] : sourceDuration;
            if (thisCut <= prevCut) continue; // skip zero-length
            var clipStart = prevCut;
            var clipEnd = (i < n)
                ? Math.min(thisCut + TAIL_SECS, sourceDuration)
                : sourceDuration;
            var layer = comp.layers.add(audioItem);
            layer.startTime = basePlayhead;
            layer.inPoint  = basePlayhead + clipStart;
            layer.outPoint = basePlayhead + clipEnd;
            layer.name = "EL " + (i + 1) + ": " + baseName;
            var label = labels[i] || "";
            if (label) {
                try {
                    var mv = new MarkerValue(label);
                    layer.property("Marker").setValueAtTime(basePlayhead + clipStart, mv);
                } catch (markerErr) {}
            }
            prevCut = thisCut;
            placed++;
        }
        app.endUndoGroup();

        return "OK:" + placed + " clips - " + baseName;
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Premiere Pro: import audio once, insert as multiple sequential clips on the audio track.
 * Uses ProjectItem.setInPoint/setOutPoint to trim each instance to its sentence range.
 */
function importAndPlaceAudioSplitPremiere(filePath, cutTimes, labelsCsv) {
    var log = [];
    try {
        var audioFile = new File(filePath);
        if (!audioFile.exists) return "ERROR:File not found: " + filePath;
        log.push("file:ok");

        try { app.enableQE(); log.push("qe:ok"); } catch(qeErr) { log.push("qe:fail"); }

        var seq = app.project.activeSequence;
        if (!seq) return "ERROR:No active sequence";
        log.push("seq:" + seq.name);

        // Find or create VO bin
        var root = app.project.rootItem;
        var voBin = null;
        for (var i = 0; i < root.children.numItems; i++) {
            if (root.children[i].name === "VO") { voBin = root.children[i]; break; }
        }
        if (!voBin) voBin = root.createBin("VO");

        // Import file
        var countBefore = voBin.children.numItems;
        app.project.importFiles([filePath], true, voBin, false);

        // Find the imported item
        var fileName = audioFile.name;
        var fileNameBase = fileName.replace(/\.[^.]+$/, "");
        var projectItem = null;
        for (var j = 0; j < voBin.children.numItems; j++) {
            var n = voBin.children[j].name;
            if (n === fileName || n === fileNameBase) { projectItem = voBin.children[j]; break; }
        }
        if (!projectItem && voBin.children.numItems > countBefore) {
            projectItem = voBin.children[voBin.children.numItems - 1];
        }
        if (!projectItem) return "ERROR:[" + log.join(",") + "] item not found";
        log.push("item:" + projectItem.name);

        // Get playhead position in seconds
        var pos = seq.getPlayerPosition();
        var startSecs = pos.seconds;

        // Constants for Premiere's tick system (1 second = 254016000000 ticks)
        var TICKS_PER_SECOND = 254016000000;
        var AUDIO_KIND = 1; // mediaType: 0=video, 1=audio

        // Capture the source's natural out point BEFORE any setIn/setOut changes it.
        // The last clip extends to this value (full source duration) so tail silence
        // isn't clipped at the last intermediate cut.
        var sourceDuration = prevCut; // fallback, overwritten below
        try {
            sourceDuration = projectItem.getOutPoint(AUDIO_KIND).seconds;
        } catch (durErr) { log.push("dur:fail=" + durErr.message); }

        var labels = (labelsCsv && labelsCsv.length) ? labelsCsv.split("|") : [];

        // cutTimes = intermediate boundaries only. N cuts -> N+1 clips.
        // Iterate i in [0..n], where i===n means the final clip going to sourceDuration.
        // timelineOffset accumulates the tail extensions added to previous clips so that
        // each subsequent insertClip lands after the previous clip's tail, not inside it.
        var prevCut = 0;
        var inserted = 0;
        var timelineOffset = 0;
        var n = cutTimes.length;
        for (var k = 0; k <= n; k++) {
            var thisCut = (k < n) ? cutTimes[k] : sourceDuration;
            if (thisCut <= prevCut) continue;

            var clipEnd = (k < n)
                ? Math.min(thisCut + TAIL_SECS, sourceDuration)
                : sourceDuration;
            var addedTail = clipEnd - thisCut; // actual tail added (may be < TAIL_SECS near end)

            var clipStartSecs = startSecs + prevCut + timelineOffset;
            var insertTicksStr = String(Math.floor(clipStartSecs * TICKS_PER_SECOND));

            try {
                // Set in/out points on the project item before inserting.
                // Premiere applies these as the source range for the inserted clip.
                projectItem.setInPoint(prevCut, AUDIO_KIND);
                projectItem.setOutPoint(clipEnd, AUDIO_KIND);

                seq.insertClip(projectItem, insertTicksStr, -1, 0);
                inserted++;
                timelineOffset += addedTail;

                var label = labels[k] || "";
                if (label) {
                    try {
                        var trackItem = _findTrackItemAtSecs(seq, clipStartSecs);
                        if (trackItem) {
                            var cm = trackItem.markers.createMarker(0);
                            cm.name = label;
                        }
                    } catch (markerErr) {}
                }
            } catch (insertErr) {
                log.push("seg" + k + ":fail=" + insertErr.message);
            }
            prevCut = thisCut;
        }

        // Restore the project item's in/out to the original source range
        // so future imports/uses aren't constrained to the last sentence's range.
        try {
            projectItem.setInPoint(0, AUDIO_KIND);
            projectItem.setOutPoint(sourceDuration, AUDIO_KIND);
        } catch (e) {}

        if (inserted === 0) return "ERROR:[" + log.join(",") + "] no clips inserted";
        return "OK:[" + log.join(",") + "] " + inserted + " clips - " + projectItem.name;

    } catch (e) {
        return "ERROR:[" + log.join(",") + "] " + e.message;
    }
}

/**
 * After Effects: import audio and place at playhead in active comp.
 */
function importAndPlaceAudioAE(filePath, markerLabel, clipDuration) {
    try {
        var audioFile = new File(filePath);
        if (!audioFile.exists) return "ERROR:File not found: " + filePath;

        var comp = app.project.activeItem;
        if (typeof CompItem === "undefined" || !(comp instanceof CompItem)) {
            return "ERROR:No active composition. Please open a composition first.";
        }

        var importOptions = new ImportOptions(audioFile);
        importOptions.sequence = false;
        importOptions.forceAlphabetical = false;

        var audioItem = app.project.importFile(importOptions);

        app.beginUndoGroup("ElevenLabs Voiceover");
        var TAIL_SECS = 0.5;
        var startTime = comp.time;
        // AE reads MP3 duration correctly — use it directly.
        // Extend comp by TAIL_SECS beyond the audio end so the layer never
        // gets clamped at the comp boundary, and there is natural breathing
        // room after the last word without needing silence baked into the file.
        var dur     = audioItem.duration;
        var clipEnd = startTime + dur;
        if (clipEnd + TAIL_SECS > comp.duration) comp.duration = clipEnd + TAIL_SECS;

        var layer = comp.layers.add(audioItem);
        layer.startTime = startTime;
        layer.inPoint   = startTime;
        layer.outPoint  = clipEnd;
        layer.name = "EL: " + audioItem.name;
        if (markerLabel) {
            try {
                var mv = new MarkerValue(markerLabel);
                layer.property("Marker").setValueAtTime(startTime, mv);
            } catch (markerErr) {}
        }
        app.endUndoGroup();

        return "OK:" + layer.name;
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Premiere Pro: import audio and insert at playhead on the first audio track.
 */
function importAndPlaceAudioPremiere(filePath, markerLabel) {
    var log = [];
    try {
        // 1. File check
        var audioFile = new File(filePath);
        if (!audioFile.exists) return "ERROR:File not found: " + filePath;
        log.push("file:ok");

        // 2. Enable QE engine
        try { app.enableQE(); log.push("qe:ok"); } catch(qeErr) { log.push("qe:fail=" + qeErr.message); }

        // 3. Sequence check
        var seq = app.project.activeSequence;
        if (!seq) return "ERROR:No active sequence -- open a sequence first.";
        log.push("seq:" + seq.name);

        // 4. Find or create VO bin
        var root  = app.project.rootItem;
        var voBin = null;
        for (var i = 0; i < root.children.numItems; i++) {
            if (root.children[i].name === "VO") { voBin = root.children[i]; break; }
        }
        if (!voBin) voBin = root.createBin("VO");
        log.push("bin:ok");

        // 5. Import
        var countBefore = voBin.children.numItems;
        app.project.importFiles([filePath], true, voBin, false);
        log.push("imported:before=" + countBefore + ",after=" + voBin.children.numItems);

        // 6. Find item
        var fileName     = audioFile.name;
        var fileNameBase = fileName.replace(/\.[^.]+$/, "");
        var projectItem  = null;
        for (var j = 0; j < voBin.children.numItems; j++) {
            var n = voBin.children[j].name;
            if (n === fileName || n === fileNameBase) { projectItem = voBin.children[j]; break; }
        }
        if (!projectItem && voBin.children.numItems > countBefore) {
            projectItem = voBin.children[voBin.children.numItems - 1];
        }
        if (!projectItem) return "ERROR:[" + log.join(",") + "] item not found in bin";
        log.push("item:" + projectItem.name + ",type:" + projectItem.type);

        // 7. Get playhead position
        var ticks = "0";
        var secs  = 0;
        try {
            var pos = seq.getPlayerPosition();
            ticks = pos.ticks;
            secs  = pos.seconds;
        } catch(posErr) { log.push("pos:fail=" + posErr.message); }
        log.push("time:ticks=" + ticks + ",secs=" + secs);

        // 8. Insert -- try three methods
        try {
            seq.insertClip(projectItem, ticks, -1, 0);
            log.push("insert1:ok");
            if (markerLabel) { try { var ti1 = _findTrackItemAtSecs(seq, secs); if (ti1) { var m1 = ti1.markers.createMarker(0); m1.name = markerLabel; } } catch(me1) {} }
            return "OK:[" + log.join(",") + "] EL: " + projectItem.name;
        } catch (e1) { log.push("insert1:fail=" + e1.message); }

        try {
            seq.audioTracks[0].insertClip(projectItem, ticks);
            log.push("insert2:ok");
            if (markerLabel) { try { var ti2 = _findTrackItemAtSecs(seq, secs); if (ti2) { var m2 = ti2.markers.createMarker(0); m2.name = markerLabel; } } catch(me2) {} }
            return "OK:[" + log.join(",") + "] EL: " + projectItem.name;
        } catch (e2) { log.push("insert2:fail=" + e2.message); }

        try {
            seq.insertClip(projectItem, secs, -1, 0);
            log.push("insert3:ok");
            if (markerLabel) { try { var ti3 = _findTrackItemAtSecs(seq, secs); if (ti3) { var m3 = ti3.markers.createMarker(0); m3.name = markerLabel; } } catch(me3) {} }
            return "OK:[" + log.join(",") + "] EL: " + projectItem.name;
        } catch (e3) { log.push("insert3:fail=" + e3.message); }

        return "ERROR:[" + log.join(",") + "]";

    } catch (e) {
        return "ERROR:[" + log.join(",") + "] " + e.message;
    }
}

/**
 * Returns basic info about the active composition.
 * @returns {string} JSON-encoded comp info, or "ERROR:<message>"
 */
function getCompInfo() {
    try {
        var comp = app.project.activeItem;
        if (typeof CompItem === "undefined" || !(comp instanceof CompItem)) {
            return "ERROR:No active composition";
        }
        return JSON.stringify({
            name: comp.name,
            duration: comp.duration,
            frameRate: comp.frameRate,
            currentTime: comp.time
        });
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Returns the project folder path.
 * AE: walks up from .aep to find a folder containing "Footage".
 * Premiere: returns the folder containing the .prproj file.
 * @returns {string} "OK:<folderPath>" or "ERROR:<message>"
 */
function getProjectFolder() {
    try {
        if (!app.project.file) {
            var appLabel = isPremiereHost() ? "Premiere" : "After Effects";
            return "ERROR:Project not saved. Please save your " + appLabel + " project first.";
        }

        // Walk up from the project file looking for an ancestor that already
        // has a "02_Footage" or "Footage" subfolder.
        // Handles nested project files (e.g. MyProject/AE/x.aep or
        // MyProject/AE/x.prproj) and NVIDIA Academy's 02_Footage convention.
        var projParent = app.project.file.parent;
        var folder = projParent;
        var maxLevels = 6;
        while (maxLevels-- > 0) {
            var footage02 = new Folder(folder.fsName + "/02_Footage");
            var footage   = new Folder(folder.fsName + "/Footage");
            if (footage02.exists || footage.exists) {
                return "OK:" + folder.fsName;
            }
            if (!folder.parent) break;
            folder = folder.parent;
        }
        return "OK:" + projParent.fsName;
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Opens the host's native file picker for selecting a PPTX file.
 * @returns {string} "OK:<fsPath>" or "CANCELLED"
 */
function selectPPTXFile() {
    try {
        var f = File.openDialog("Select a PPTX file", "PPTX Files:*.pptx,All Files:*.*");
        if (!f) return "CANCELLED";
        return "OK:" + f.fsName;
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Opens a file picker filtered to ZIP files.
 * @returns {string} "OK:<fsPath>" or "CANCELLED" or "ERROR:<message>"
 */
function selectZipFile() {
    try {
        var f = File.openDialog("Select plugin ZIP file", "ZIP Files:*.zip,All Files:*.*");
        if (!f) return "CANCELLED";
        return "OK:" + f.fsName;
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Opens the host's native folder picker.
 * @returns {string} "OK:<fsPath>" or "CANCELLED" or "ERROR:<message>"
 */
function selectFolder() {
    try {
        var f = Folder.selectDialog("Select update source folder");
        if (!f) return "CANCELLED";
        return "OK:" + f.fsName;
    } catch (e) {
        return "ERROR:" + e.message;
    }
}

/**
 * Returns the current playhead time (in seconds).
 * @returns {string} time as string, or "ERROR:<message>"
 */
function getCurrentTime() {
    try {
        if (isPremiereHost()) {
            var seq = app.project.activeSequence;
            if (!seq) return "ERROR:No active sequence";
            return String(seq.getPlayerPosition().seconds);
        }
        var comp = app.project.activeItem;
        if (typeof CompItem === "undefined" || !(comp instanceof CompItem)) return "ERROR:No active composition";
        return String(comp.time);
    } catch (e) {
        return "ERROR:" + e.message;
    }
}
